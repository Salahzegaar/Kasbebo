# R8 rules for an optional optimized release build.
# CodeAssist/mobile builds currently use minifyEnabled=false to avoid R8 VM OOM.
# Do not remove these rules; they are used if R8 is re-enabled on a sufficiently provisioned build host.

# R8 / release hardening
-keep class com.example.bookstoremanager.data.CustomerOrder { *; }
-keep class com.example.bookstoremanager.data.OrderItem { *; }
-keep class com.example.bookstoremanager.data.Product { *; }
-keep class com.example.bookstoremanager.data.SaleRecord { *; }
-keep class com.example.bookstoremanager.data.ExpenseRecord { *; }

# Firebase Messaging discovers the service from AndroidManifest.xml.
-keep class com.example.bookstoremanager.MyFirebaseMessagingService { *; }

# Keep useful line information in release crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
