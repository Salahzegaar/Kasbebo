# Kasebo — Development Plan (Forward Only)

## 1.8.2 — Invoice Archive Store Session Fix
- Use the authenticated global SessionStore store ID when opening the invoice archive.
- Keep the archive backed by the current store-local SQLite sales ledger.
- Verify online and offline invoices appear in the archive without app restart.
- Preserve store isolation and existing offline synchronization behavior.

## 1.8.3 — Invoice Archive UX
- Add archive refresh/reload behavior without leaving the screen.
- Improve invoice status presentation for Pending, Syncing, and Completed.
- Add invoice search by invoice ID.

## 1.9.0 — Final Release Regression
- Full regression testing for POS, offline persistence, synchronization, permissions, reports, exports, and invoice archive.
- Release readiness verification on supported Android devices.
