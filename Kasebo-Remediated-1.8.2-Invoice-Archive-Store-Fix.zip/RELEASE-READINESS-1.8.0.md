# Kasebo 1.8.0 — Release Readiness Checklist

## Build
- [ ] Clean Release build in CodeAssist
- [ ] 0 compiler/D8 warnings
- [ ] APK installed and launches
- [ ] Release signing verified
- [ ] No R8/minification or resource shrinking

## Offline / Online
- [ ] Create/edit inventory while online
- [ ] Make sale while online
- [ ] Disable internet and make sale
- [ ] Force-close and reopen while offline
- [ ] Verify stock, sale, invoice and totals remain visible
- [ ] Restore internet and verify automatic queue synchronization
- [ ] Return app to foreground and verify queued work retries
- [ ] Verify retry does not duplicate the invoice or sale

## Data isolation
- [ ] Store A cannot read Store B
- [ ] Store A cannot modify Store B
- [ ] Local database/cache is store-scoped
- [ ] Logout clears active in-memory store state

## POS / Inventory / Invoices
- [ ] Server-side stock mutation remains transactional
- [ ] Sale IDs and invoice IDs remain stable
- [ ] Pending invoices remain visible until confirmed
- [ ] Conflict/retry state is preserved
- [ ] Reset permanently removes sales/invoice data after successful server reset

## Users / Permissions
- [ ] Owner/admin/cashier roles are enforced
- [ ] Cashier cannot access privileged settings
- [ ] Employee invite is one-time and email-bound
- [ ] Password fields are never displayed as plaintext

## Reports / Export
- [ ] Sales filters
- [ ] Financial totals
- [ ] Inventory report
- [ ] CSV export
- [ ] PDF export
- [ ] Android share sheet

## Security rules
- [ ] Firebase Rules deployed from the reviewed `database.rules.json`
- [ ] Existing sales cannot be rewritten with different immutable fields
- [ ] Committed checkout operations cannot be rewritten
- [ ] Unauthorized reads/writes are denied

## Final acceptance
- [ ] Release APK tested on at least two Android devices/Android versions
- [ ] Offline → relaunch → online scenario passes
- [ ] No data loss observed
- [ ] No duplicate sales observed
