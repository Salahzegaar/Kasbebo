# Kasebo — Architecture & Security Review

## Scope
Static review of the supplied Android/Compose + Firebase Realtime Database project.

## Current assessment
- **Architecture:** 6/10
- **Security before remediation:** 4/10
- **Security after the included remediation:** 7.5/10
- **Data consistency:** 5/10
- **Maintainability:** 5/10

The project has a usable feature base, but its original data layer mixes UI state, SharedPreferences, SQLite, JSON files, and Firebase directly. The largest risks were authorization rules and store-to-store cache isolation.

## Critical findings fixed in this release
1. **Store takeover through `ownerUid`**
   - The previous store-level write rule allowed an authenticated user to write a new `ownerUid`.
   - The store rule now permits creation only by the creator and prevents changing `ownerUid` after creation.

2. **UID/email account mapping**
   - New `Kasebo_Users` records are keyed by Firebase UID instead of a collision-prone sanitized email.
   - A backward-compatible migration path is included for old records.

3. **Non-atomic account/store creation**
   - Registration now uses a Firebase multi-location update, reducing orphan account/store states.

4. **Cross-account local cache leakage**
   - SQLite databases and local JSON caches are now separated by a SHA-256-derived store-specific filename.
   - Session state is separated from store-scoped business preferences.
   - Logout stops listeners and clears in-memory business state.

5. **Stale-data display during session startup**
   - The UI no longer treats a locally stored store code as proof of authorization.
   - Firebase Auth plus server-side ownership validation determine access.

6. **Incomplete cloud-to-local synchronization**
   - Fetch/realtime sync now replaces products, sales, expenses, and customers instead of updating only part of the local state.

7. **Privileged password caching**
   - The settings gate now uses Firebase re-authentication rather than accepting a previously stored owner-password verifier.

8. **Admin write-rule path errors**
   - Direct child rules for products/sales/expenses/customers were corrected to reference the store parent correctly.
   - Store-root writes are owner-only; admin operations use explicit child permissions.

9. **Release hardening**
   - Release R8/minification is enabled with keep rules for Firebase-reflected model classes and the messaging service.

## Important remaining architectural risks
- Whole-store `updateChildren()` synchronization can still produce last-write-wins conflicts on multiple devices.
- Checkout currently mutates local stock and then synchronizes; true server-authoritative stock transactions are still required to prevent overselling under concurrency.
- Sales have no stable immutable transaction ID in the current model, making idempotent retry handling difficult.
- Employee management is still local metadata rather than Firebase Authentication + protected membership.
- Company/supplier/settings functionality is not yet fully represented by a normalized cloud repository.
- Realtime Database rules are the security boundary; UI role checks must never be considered security.
- Firebase App Check should be enabled before production deployment.
- Automated unit/integration/rules tests are still required.

## Recommended production architecture
UI (Compose)
→ ViewModel/StateFlow
→ Use Cases
→ Repository interfaces
→ Local data source (store-scoped)
→ Firebase data source (rules-authorized)

Authentication/session:
FirebaseAuth → SessionStore → ViewModels

Authorization:
Firebase Security Rules → final enforcement

Business mutations:
server transaction / atomic write → local cache update → UI state

## Verification status
The archive was statically inspected and the Firebase rules JSON validates. A full Android build could not be executed in this environment because the supplied project is a CodeAssist-style module without the Android SDK/Gradle dependency environment required for a complete compile.


## 1.4.0 critical integrity remediation
- Checkout now uses a Firebase Realtime Database transaction for server-authoritative stock/sale/totals mutation.
- Sale lines have immutable IDs and invoices have idempotency records.
- Pending invoice fingerprints support safe retry of the same checkout operation.
- Firebase rules protect checkout operations and validate sale-line structure.
- See `CRITICAL-INTEGRITY-TEST-MATRIX.md` for the required isolation and concurrency verification.


## 1.4.1 Multi-device hardening

- Customer-order processing now uses an atomic order claim followed by a server-side products transaction.
- Order processing no longer rewrites the complete products or sales collections.
- Background synchronization merges entities instead of replacing entire collections.
- Explicit product, expense, and customer deletions propagate to Firebase.
- Checkout remains server-authoritative and idempotent through the existing 1.4.0 checkout transaction.
- Remaining limitation: multi-field edits to the same individual entity are still last-writer-wins; durable offline conflict resolution is planned for 1.4.x/1.7.

## 1.5.0 Users & Permissions remediation

- Firebase Auth UID is now the employee identity boundary.
- Owner-created employee invitations are time-limited and bound to a specific email and store.
- Employee claim creates a UID-keyed user record and a UID-keyed store membership in one multi-location update.
- SessionStore stores the authenticated UID, store ID, and normalized role; member login is verified against the live store membership.
- Inactive members are rejected during login.
- Owner/admin/cashier roles are represented in Firebase membership records; UI restrictions are convenience checks only.
- Firebase Rules retain the owner-only parent store write boundary. Cashier access is not granted by weakening a parent transaction path.
- Cashier checkout remains intentionally backend-gated until a server-authoritative callable/backend path is available; this avoids introducing a privilege-escalation hole.
- The local employee list remains operational metadata only; authorization is never derived from it.


## 1.6.0 Reports & Export remediation
- Added store-scoped report export UI using the active InventoryManager session only.
- Added PDF/CSV export through user-selected Android document URIs; no report is written to a global business-data directory.
- Added standard Android share-sheet support with URI read permission only.
- Added staffUid to new SaleRecord records and checkout writes for audit traceability.
- Added local database migration for staffUid while preserving legacy sales.
- Firebase sales validation requires staffUid to equal the authenticated UID for new/updated records; legacy records can remain readable without rewriting their historical identity.

## 1.7.0 Offline & Performance remediation
- Local caches remain keyed by a SHA-256-derived store-specific database/file name.
- Offline dirty state and pending deletions are keyed per store, preventing cross-store replay.
- Realtime Firebase snapshots are ignored while unsynced local changes exist; this prevents an older remote snapshot from replacing pending local work.
- Normal sync uses non-destructive per-collection Firebase transactions instead of replacing the complete store tree.
- Deletes are persisted as pending IDs and replayed transactionally; both Firebase child key and legacy `id` are checked.
- A generation counter prevents clearing the dirty flag when a new local edit occurs during an active sync.
- Checkout remains online/server-authoritative; offline CRUD edits are supported, but offline sales are intentionally blocked to preserve stock integrity.
- Firebase local persistence is enabled early in `MainActivity` for faster/offline reads.

## 1.7.4 — Sales, Invoice Archive & Offline Hardening
- Invoice archive is a dedicated navigation section under Sales & Invoices.
- Invoice grouping uses immutable invoice IDs where available, preserving legacy fallback records.
- Offline invoices remain local and visibly pending until the server-authoritative checkout transaction commits.
- Final reset is online-only and deletes sales, expenses, checkout operation records and reset archives from the cloud before clearing local transaction data.
- Local user deletion removes the local password verifier and role entry; the primary `admin` identifier is protected.
- The client never displays or stores a recoverable plaintext administrator password.
