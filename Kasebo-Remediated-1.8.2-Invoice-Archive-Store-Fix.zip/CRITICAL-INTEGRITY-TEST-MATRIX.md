# Kasebo 1.4.0 — Critical Integrity Test Matrix

This document is the verification checklist for the four P0 issues. It is intentionally forward-looking and does not replace the application source tests.

## 1. Server-authoritative checkout
1. Store has product A with stock 5.
2. Device sells quantity 3.
3. Confirm Firebase transaction contains: stock 2, one invoice operation, one sale line, and totals increased once.
4. Simulate a stale local cache that still says stock 5; the server must reject a quantity greater than current server stock.

## 2. Two-device concurrency
1. Device A and Device B load the same product with stock 1.
2. Both attempt to sell quantity 1 at nearly the same time.
3. Exactly one checkout commits.
4. Final stock is 0.
5. Exactly one invoice operation exists for the successful checkout.
6. The losing device receives an error and must refresh authoritative data.

## 3. Idempotent retry
1. Start a checkout and force a client/network failure after the server commit.
2. Retry the same cart without changing its fingerprint.
3. The pending invoice ID must be reused.
4. Firebase must detect `checkoutOperations/{invoiceId}` and perform no second stock/totals/sale mutation.
5. The client refreshes from Firebase and displays the already committed invoice.
6. Change the cart after a failed attempt; a new fingerprint must generate a new invoice ID.

## 4. Store isolation
### Account A / Account B
- Login A, open store A, confirm local and cloud data.
- Logout A.
- Login B, open store B.
- Confirm no products, sales, customers, expenses, preferences, or cached totals from A are visible.
- Attempt direct access to store A while authenticated as B; Firebase Rules must deny it.
- Logout B and confirm the UI cannot display the previous store's business data.

### Store switching
- Switch A → B → A and verify each local DB/cache is restored only for its own store.
- Verify old Firebase listeners cannot update the current screen after a switch.

### Ownership protection
- Attempt to modify `ownerUid` from a non-owner account; Rules must reject it.

## Release verification
- Run the CodeAssist Release build on the target device.
- Install the APK and execute the complete matrix above.
- Keep R8/minification disabled for this CodeAssist release unless explicitly reintroduced after memory testing.
