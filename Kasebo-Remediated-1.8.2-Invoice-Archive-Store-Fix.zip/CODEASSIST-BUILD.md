# Kasebo — CodeAssist Build Notes

## CameraX / Guava

CameraX exposes `com.google.common.util.concurrent.ListenableFuture` from `ProcessCameraProvider.getInstance(...)`. The app therefore requires Guava on the module classpath even when the application code does not directly import Guava.

The module explicitly declares:

`com.google.guava:guava:33.2.1-android`

This prevents CodeAssist/Kotlin compiler errors such as:

- `Cannot access class com.google.common.util.concurrent.ListenableFuture`
- `Unresolved reference addListener`
- `Unresolved reference get`

## R8 / memory

R8 and resource shrinking remain disabled for this CodeAssist/mobile build profile to avoid dexer out-of-memory failures. Firebase Authentication/Database rules and application-level session isolation are independent of R8.

For a production CI/release build on a machine with sufficient memory, R8 can be enabled after a clean dependency/build verification.
