package com.example.bookstoremanager

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DatabaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging

// استيراد الحزم الأساسية
import com.example.bookstoremanager.data.*
import com.example.bookstoremanager.ui.*

class MainActivity : ComponentActivity() {
    private val inventoryManager by lazy { InventoryManager(this) }
    private val authManager by lazy { AuthManager(this) }

    override fun onStart() {
        super.onStart()
        // Retry durable offline work whenever the app returns to the foreground.
        // This complements the network callback and avoids requiring a full app restart.
        if (FirebaseAuth.getInstance().currentUser != null) {
            inventoryManager.onAppForegrounded()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // تفعيل كاش Firebase المحلي مبكراً لتحسين القراءة دون اتصال.
        try {
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
        } catch (_: DatabaseException) {
            // قد يكون التفعيل قد تم مسبقاً من دورة حياة التطبيق.
        }

        // 🛡️ طلب الأذونات المتقدمة (الكاميرا، الإشعارات، والبلوتوث للطابعات)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 100)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val permissions = arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            )
            if (permissions.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
                requestPermissions(permissions, 102)
            }
        }

        setContent {
            val prefs = getSharedPreferences("KaseboSession", Context.MODE_PRIVATE)
            var currentStoreId by remember { mutableStateOf(prefs.getString("store_secret_id", "") ?: "") }

            var isDark by remember { mutableStateOf(prefs.getBoolean("is_dark_mode", true)) }
            // Never trust locally persisted session state as proof of authorization.
            // Firebase Auth + database ownership validation below are the authority.
            var isLoggedIn by remember { mutableStateOf(false) }
            var refreshTrigger by remember { mutableStateOf(0) }
            var newlyCreatedStoreCode by remember { mutableStateOf<String?>(null) }

            LaunchedEffect(currentStoreId) {
                if (currentStoreId.isNotBlank() && FirebaseAuth.getInstance().currentUser != null) {
                    authManager.validateSession(
                        storeCode = currentStoreId,
                        onValid = {
                            inventoryManager.bindStore(currentStoreId, startListener = true)
                            isLoggedIn = true
                        },
                        onInvalid = {
                            inventoryManager.clearSession()
                            isLoggedIn = false
                            currentStoreId = ""
                            prefs.edit().remove("store_secret_id").apply()
                        }
                    )
                } else {
                    isLoggedIn = false
                }
            }

            // ☁️ بمجرد الدخول، الاستماع للطلبات وجلب رمز الإشعارات (FCM Token)
            LaunchedEffect(currentStoreId, isLoggedIn) {
                if (currentStoreId.isNotBlank() && isLoggedIn) {
                    inventoryManager.listenForIncomingCustomerOrders(
                        storeId = currentStoreId,
                        onOrdersUpdated = { _ ->
                            refreshTrigger++
                            // Do not force a Firebase read while offline.
                            // InventoryManager already loaded the durable local
                            // cache during bindStore(), so an offline relaunch
                            // must keep sales, invoices and stock visible.
                            if (inventoryManager.isNetworkAvailable()) {
                                inventoryManager.fetchDataFromFirebase(
                                    storeId = currentStoreId,
                                    onSuccess = { refreshTrigger++ },
                                    onFailure = { refreshTrigger++ }
                                )
                            }
                        }
                    )

                    FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val token = task.result
                            if (!token.isNullOrBlank()) {
                                FirebaseDatabase.getInstance().getReference("Kasebo_Stores")
                                .child(currentStoreId)
                                .child("fcmToken")
                                .setValue(token)
                            }
                        }
                    }
                }
            }

            val appColors = if (isDark) {
                darkColorScheme(
                    primary = AppTheme.PremiumGold,
                    secondary = AppTheme.AccentTeal,
                    background = AppTheme.bg(true),
                    surface = AppTheme.card(true)
                )
            } else {
                lightColorScheme(
                    primary = AppTheme.PremiumGoldDark,
                    secondary = AppTheme.AccentTeal,
                    background = AppTheme.bg(false),
                    surface = AppTheme.card(false)
                )
            }

            val appShapes = Shapes(
                extraSmall = RoundedCornerShape(8.dp),
                small = RoundedCornerShape(12.dp),
                medium = RoundedCornerShape(16.dp),
                large = RoundedCornerShape(24.dp),
                extraLarge = RoundedCornerShape(28.dp)
            )

            MaterialTheme(colorScheme = appColors, shapes = appShapes) {
                Surface(modifier = Modifier.fillMaxSize(), color = AppTheme.bg(isDark)) {

                    // 🚀 البحث عن التحديثات الإجبارية
                    CheckForAppUpdates(isDark = isDark)

                    // 🎉 إظهار كود المتجر للمستخدم الجديد
                    if (newlyCreatedStoreCode != null) {
                        NewStoreWelcomeDialog(
                            storeCode = newlyCreatedStoreCode!!,
                            isDark = isDark,
                            onDismiss = {
                                newlyCreatedStoreCode = null
                                isLoggedIn = true
                                refreshTrigger++
                            }
                        )
                    }

                    if (!isLoggedIn) {
                        LoginAuthScreen(
                            isDark = isDark,
                            onLoginSuccess = { result ->
                                currentStoreId = prefs.getString("store_secret_id", "") ?: ""
                                isLoggedIn = currentStoreId.isNotBlank() && FirebaseAuth.getInstance().currentUser != null
                            }
                        )
                    } else {
                        StoreManagerApp(
                            inventoryManager = inventoryManager,
                            isDarkMode = isDark,
                            onThemeChange = { newTheme ->
                                isDark = newTheme
                                prefs.edit().putBoolean("is_dark_mode", newTheme).apply()
                            },
                            onDataChanged = { refreshTrigger++ }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 🚀 نظام جلب تحديثات كاسبو تلقائياً
// ==========================================
@Composable
fun CheckForAppUpdates(isDark: Boolean) {
    var showUpdateDialog by remember { mutableStateOf(false) }
    var updateUrl by remember { mutableStateOf("") }
    val context = LocalContext.current

    val currentVersionCode = try {
        val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode.toInt()
        } else {
            @Suppress("DEPRECATION")
            packageInfo.versionCode
        }
    } catch (e: Exception) {
        1
    }

    LaunchedEffect(Unit) {
        val databaseRef = FirebaseDatabase.getInstance().getReference("Kasebo_App_Update")
        databaseRef.get().addOnSuccessListener { snapshot ->
            val latestVersion = snapshot.child("LatestVersion").getValue(Int::class.java) ?: currentVersionCode
            updateUrl = snapshot.child("updateUrl").getValue(String::class.java) ?: ""

            if (latestVersion > currentVersionCode && updateUrl.isNotBlank()) {
                showUpdateDialog = true
            }
        }
    }

    if (showUpdateDialog) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = AppTheme.card(isDark),
            title = { Text("🚀 توفر تحديث جديد لتطبيق كاسبو", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = { Text("يتوفر إصدار جديد من التطبيق يحتوي على تحسينات هامة للأمان والمزامنة. يرجى التحديث الآن.", color = AppTheme.subText(isDark), fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl))
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "الرابط غير صالح!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppTheme.GoldPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("تحميل التحديث الآن 📥", color = AppTheme.GoldPrimaryText, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            }
        )
    }
}

// ==========================================
// 🎉 نافذة الترحيب بالمتجر الجديد
// ==========================================
@Composable
fun NewStoreWelcomeDialog(
    storeCode: String,
    isDark: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = { },
        containerColor = AppTheme.card(isDark),
        shape = RoundedCornerShape(20.dp),
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("🎉 تم إنشاء متجرك بنجاح!", color = AppTheme.GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.height(4.dp))
                Text("احفظ كود متجرك السري", color = AppTheme.text(isDark), fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                    .fillMaxWidth()
                    .background(AppTheme.inputBg(isDark), RoundedCornerShape(16.dp))
                    .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = storeCode,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = AppTheme.GoldPrimary,
                        letterSpacing = 2.sp
                    )
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("💡 لماذا هذا الكود مهم جداً؟", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("1️⃣ هو مفتاح المزامنة للوصول لمتجرك من أجهزة أخرى.", color = AppTheme.subText(isDark), fontSize = 12.sp)
                    Text("2️⃣ يمكنك إعطاؤه لزبائنك لطلب المنتجات والتسوق إلكترونياً.", color = AppTheme.subText(isDark), fontSize = 12.sp)
                    Text("3️⃣ يلزمك لإعادة فتح حسابك في حال تم تغيير الهاتف.", color = AppTheme.subText(isDark), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("StoreCode", storeCode)
                        clipboard.setPrimaryClip(clip)

                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "🔑 كود متجري في تطبيق كاسبو Kasebo هو: $storeCode\nاستخدم هذا الكود للبحث والتسوق مباشرة."
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "حفظ/مشاركة كود المتجر عبر..."))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AppTheme.GoldPrimary)
                ) {
                    Text("نسخ الكود ومشاركته 📤", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AppTheme.inputBg(isDark))
                ) {
                    Text("فهمت ذلك، الدخول للمتجر 🚀", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold)
                }
            }
        }
    )
}
