package com.example.bookstoremanager.ui

import com.example.bookstoremanager.AppTheme
import com.example.bookstoremanager.data.InventoryManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PendingOfflineSalesScreen(
    inventoryManager: InventoryManager,
    isDark: Boolean,
    onBack: () -> Unit
) {
    var refresh by remember { mutableIntStateOf(0) }
    val pending = remember(refresh) { inventoryManager.getPendingOfflineSaleDetails() }
    val dateFormat = remember { SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()) }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark))) {
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "عودة", tint = AppTheme.text(isDark))
                }
                Text("المبيعات المعلقة", color = AppTheme.text(isDark), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = { refresh++ }) {
                Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = AppTheme.GoldPrimary)
            }
        }

        if (pending.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Receipt, null, tint = AppTheme.subText(isDark), modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("لا توجد مبيعات معلقة", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold)
                    Text("المبيعات التي تمت مزامنتها لا تظهر هنا.", color = AppTheme.subText(isDark), fontSize = 12.sp)
                }
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)),
                    border = BorderStroke(1.dp, AppTheme.cardBorder(isDark))
                ) {
                    Text(
                        "${pending.size} فاتورة بانتظار التأكيد على الخادم",
                        modifier = Modifier.padding(14.dp),
                        color = AppTheme.text(isDark), fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                }
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(pending, key = { it.invoiceId }) { item ->
                        val (label, labelColor) = when (item.status) {
                            "SYNCING" -> "جاري المزامنة" to AppTheme.GoldPrimary
                            "CONFLICT" -> "تعارض — يحتاج مراجعة" to Color(0xFFB42318)
                            "RETRY" -> "فشل — سيعاد المحاولة" to Color(0xFFB54708)
                            else -> "بانتظار المزامنة" to Color(0xFFB45A00)
                        }
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, AppTheme.cardBorder(isDark))
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.invoiceId, color = AppTheme.text(isDark), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(dateFormat.format(Date(item.timestamp)), color = AppTheme.subText(isDark), fontSize = 11.sp)
                                    }
                                    Text(label, color = labelColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("عدد العناصر: ${item.itemCount}", color = AppTheme.subText(isDark), fontSize = 12.sp)
                                if (item.error.isNotBlank()) {
                                    Text(item.error, color = labelColor, fontSize = 11.sp)
                                }
                                OutlinedButton(
                                    onClick = { inventoryManager.retryPendingOfflineSale(item.invoiceId); refresh++ },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = item.status != "SYNCING"
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(17.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("إعادة المحاولة")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
