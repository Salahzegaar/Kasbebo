@file:Suppress("DEPRECATION")
package com.example.bookstoremanager.ui

import com.example.bookstoremanager.AppTheme

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

import com.example.bookstoremanager.*
import com.example.bookstoremanager.data.AuthManager
import com.example.bookstoremanager.data.*

@Composable
fun SettingsScreen(
    inventoryManager: InventoryManager,
    isDark: Boolean,
    onThemeChange: (Boolean) -> Unit,
    onDataChanged: () -> Unit,
    onBack: () -> Unit
) {
    var activePage by remember { mutableStateOf("menu") }

    BackHandler(enabled = activePage != "menu") { activePage = "menu" }

    when (activePage) {
        "menu" -> SettingsMainMenu(isDark, onBack = onBack, onNavigate = { activePage = it })
        "company" -> CompanyInfoSubScreen(isDark, onBack = { activePage = "menu" })
        "ticket" -> TicketInfoSubScreen(isDark, onBack = { activePage = "menu" })
        "units" -> ListManagerSubScreen("الوحدات ⚖️", "تسيير وحدات المنتجات", "عند التعديل يتم تحديث حقل الوحدة في المنتجات.", "اسم الوحدة", "store_units", "قطعة,كيلو,رطل,لتر,صندوق", isDark, onBack = { activePage = "menu" })
        "categories" -> ListManagerSubScreen("الفئات 🏷️", "تسيير فئات المنتجات", "عند التعديل يتم تحديث فئة المنتجات.", "اسم الفئة", "store_categories", "عام", isDark, onBack = { activePage = "menu" })
        "passwords" -> PasswordsSubScreen(isDark, onBack = { activePage = "menu" })
        "users" -> UsersSubScreen(isDark, onBack = { activePage = "menu" })
        "audit" -> AuditSubScreen(isDark, onBack = { activePage = "menu" })
        "other" -> OtherSettingsSubScreen(
            isDark = isDark,
            inventoryManager = inventoryManager,
            onThemeChange = onThemeChange,
            onDataChanged = onDataChanged,
            onBack = { activePage = "menu" }
        )
        "backup" -> BackupSubScreen(inventoryManager, isDark, onDataChanged, onBack = { activePage = "menu" })
        // 🚀 إضافة توجيه التصفح لشاشة الإعدادات المتقدمة الجديدة
        "advanced_store" -> AdvancedStoreSettingsScreen(isDark = isDark, onBack = { activePage = "menu" })
    }
}

@Composable
fun getSettingsFieldColors(isDark: Boolean) = OutlinedTextFieldDefaults.colors(
    focusedTextColor = AppTheme.text(isDark), unfocusedTextColor = AppTheme.text(isDark),
    focusedContainerColor = AppTheme.inputBg(isDark), unfocusedContainerColor = AppTheme.inputBg(isDark),
    focusedBorderColor = AppTheme.GoldPrimary, unfocusedBorderColor = AppTheme.cardBorder(isDark),
    focusedLabelColor = AppTheme.GoldPrimary, unfocusedLabelColor = AppTheme.subText(isDark)
)

// ==========================================
// 1️⃣ القائمة الرئيسية (Main Menu)
// ==========================================
@Composable
fun SettingsMainMenu(isDark: Boolean, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(bottom = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "عودة", tint = AppTheme.text(isDark)) }
            Text("⚙️ الإعدادات", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
            Spacer(modifier = Modifier.size(48.dp))
        }

        SettingsMenuItem("معلومات الشركة", "إدارة بيانات مؤسستك وسجلك التجاري.", Icons.Default.Business, AppTheme.AccentSky, isDark) { onNavigate("company") }
        SettingsMenuItem("معلومات التذكرة", "رسالة الترحيب وتذييل التذكرة", Icons.Default.Receipt, AppTheme.PremiumGold, isDark) { onNavigate("ticket") }
        SettingsMenuItem("الوحدات", "يفتح صفحة التسيير المخصصة.", Icons.Default.Scale, AppTheme.ColorDanger, isDark) { onNavigate("units") }
        SettingsMenuItem("الفئات", "يفتح صفحة التسيير المخصصة.", Icons.Default.Label, AppTheme.PremiumGold, isDark) { onNavigate("categories") }
        SettingsMenuItem("كلمات المرور", "تغيير كلمة مرور المستخدمين.", Icons.Default.VpnKey, AppTheme.PremiumGold, isDark) { onNavigate("passwords") }
        SettingsMenuItem("المستخدمون", "إضافة المستخدمين وتحديد صلاحياتهم.", Icons.Default.GroupAdd, AppTheme.ColorDanger, isDark) { onNavigate("users") }
        SettingsMenuItem("تدقيق الجرد", "سجل تصحيحات المخزون المؤكدة.", Icons.Default.FactCheck, AppTheme.AccentSky, isDark) { onNavigate("audit") }
        SettingsMenuItem("النسخ الاحتياطي", "نسخ يدوي وسجل ونسخ تلقائي.", Icons.Default.Storage, AppTheme.PremiumGold, isDark) { onNavigate("backup") }

        // 🚀 عنصر القائمة الجديد لإعدادات المتجر المتقدمة
        SettingsMenuItem("إعدادات المتجر المتقدمة", "المخزون السالب، التنبيهات، نماذج الفواتير.", Icons.Default.SettingsApplications, AppTheme.PremiumGold, isDark) { onNavigate("advanced_store") }

        SettingsMenuItem("إعدادات أخرى", "المظهر، التصفير، والمزيد.", Icons.Default.Tune, AppTheme.ColorDanger, isDark) { onNavigate("other") }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
fun SettingsMenuItem(title: String, subtitle: String, icon: ImageVector, iconTint: Color, isDark: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().height(85.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)),
        shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, AppTheme.cardBorder(isDark)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(45.dp).clip(RoundedCornerShape(14.dp)).background(iconTint.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark), fontSize = 16.sp)
                Text(subtitle, color = AppTheme.subText(isDark), fontSize = 11.sp)
            }
        }
    }
}

// ==========================================
// 🚀 جديد: شاشة إعدادات المتجر المتقدمة
// ==========================================
@Composable
fun AdvancedStoreSettingsScreen(isDark: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = SessionStore.currentStorePrefs(context)

    var allowNegativeInventory by remember { mutableStateOf(prefs.getBoolean("allow_negative_inventory", false)) }
    var expiryDays by remember { mutableStateOf(prefs.getInt("expiry_alert_days", 0).toString()) }
    var selectedTemplate by remember { mutableStateOf(prefs.getString("invoice_template", "classic") ?: "classic") }

    val bluePrimary = AppTheme.PremiumGold
    val grayBg = if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9)

    Column(
        modifier = Modifier
        .fillMaxSize()
        .background(AppTheme.bg(isDark))
        .padding(16.dp)
        .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // 1️⃣ قسم المخزون السالب
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
            Text("السماح بالبيع بمخزون سالب", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
            Text("يسمح أو يمنع البيع عند عدم كفاية المخزون.", fontSize = 12.sp, color = AppTheme.subText(isDark))

            Spacer(modifier = Modifier.height(16.dp))

            // أزرار OUI / NON
            Row(modifier = Modifier.fillMaxWidth().height(50.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    modifier = Modifier.weight(1f).fillMaxHeight().clickable { allowNegativeInventory = false },
                    shape = RoundedCornerShape(12.dp),
                    color = if (!allowNegativeInventory) grayBg else Color.Transparent,
                    border = BorderStroke(1.dp, if (!allowNegativeInventory) Color.Transparent else AppTheme.cardBorder(isDark))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("NON", fontWeight = FontWeight.Bold, color = if (!allowNegativeInventory) AppTheme.text(isDark) else AppTheme.subText(isDark))
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f).fillMaxHeight().clickable { allowNegativeInventory = true },
                    shape = RoundedCornerShape(12.dp),
                    color = if (allowNegativeInventory) bluePrimary else Color.Transparent,
                    border = BorderStroke(1.dp, if (allowNegativeInventory) Color.Transparent else AppTheme.cardBorder(isDark))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("OUI", fontWeight = FontWeight.Bold, color = if (allowNegativeInventory) Color.White else AppTheme.subText(isDark))
                    }
                }
            }
        }

        // 2️⃣ حقل إدخال أيام الصلاحية
        OutlinedTextField(
            value = expiryDays,
            onValueChange = { expiryDays = it },
            label = { Text("تنبيه أيام الصلاحية", fontSize = 12.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = bluePrimary,
                unfocusedBorderColor = AppTheme.cardBorder(isDark),
                focusedTextColor = AppTheme.text(isDark),
                unfocusedTextColor = AppTheme.text(isDark)
            )
        )

        // 3️⃣ قسم نماذج الفاتورة
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
            Text("نموذج الفاتورة", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
            Spacer(modifier = Modifier.height(16.dp))

            InvoiceTemplateCard(
                title = "عصري", desc = "شريط أزرق ومربعات للزبون والشركة.", isSelected = selectedTemplate == "modern", isDark = isDark,
                onClick = { selectedTemplate = "modern" }, blueColor = bluePrimary
            )
            Spacer(modifier = Modifier.height(12.dp))
            InvoiceTemplateCard(
                title = "كلاسيكي", desc = "بسيط بالأبيض والأسود وقريب من الوثائق.", isSelected = selectedTemplate == "classic", isDark = isDark,
                onClick = { selectedTemplate = "classic" }, blueColor = bluePrimary
            )
            Spacer(modifier = Modifier.height(12.dp))
            InvoiceTemplateCard(
                title = "مختصر", desc = "أكثر كثافة للفواتير ذات العديد من الأسطر.", isSelected = selectedTemplate == "compact", isDark = isDark,
                onClick = { selectedTemplate = "compact" }, blueColor = bluePrimary
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        // 4️⃣ أزرار الحفظ والرجوع
        Row(modifier = Modifier.fillMaxWidth().height(55.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = grayBg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f).fillMaxHeight()
            ) {
                Text("رجوع", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Button(
                onClick = {
                    val parsedExpiryDays = expiryDays.trim().toIntOrNull()
                    if (parsedExpiryDays == null || parsedExpiryDays < 0 || parsedExpiryDays > 3650) {
                        Toast.makeText(context, "أدخل عدد أيام صحيحاً بين 0 و3650", Toast.LENGTH_LONG).show()
                    } else {
                        prefs.edit()
                            .putBoolean("allow_negative_inventory", allowNegativeInventory)
                            .putInt("expiry_alert_days", parsedExpiryDays)
                            .putString("invoice_template", selectedTemplate)
                            .apply()

                        Toast.makeText(context, "تم حفظ الإعدادات بنجاح! 💾", Toast.LENGTH_SHORT).show()
                        onBack()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = bluePrimary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.weight(1f).fillMaxHeight()
            ) {
                Text("حفظ 💾", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun InvoiceTemplateCard(title: String, desc: String, isSelected: Boolean, isDark: Boolean, onClick: () -> Unit, blueColor: Color) {
    val bgColor = if (isSelected) Color.Transparent else (if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9))
    val borderColor = if (isSelected) blueColor else Color.Transparent
    val titleColor = if (isSelected) blueColor else AppTheme.text(isDark)

    Surface(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = bgColor,
        border = BorderStroke(1.5.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = titleColor)
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, fontSize = 12.sp, color = AppTheme.subText(isDark))
        }
    }
}

// ==========================================
// 2️⃣ شاشة معلومات التذكرة
// ==========================================
@Composable
fun TicketInfoSubScreen(isDark: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = SessionStore.currentStorePrefs(context)

    var welcomeMsg by remember { mutableStateOf(prefs.getString("ticket_welcome", "مرحباً بكم في متجرنا") ?: "") }
    var footerMsg by remember { mutableStateOf(prefs.getString("ticket_footer", "شكراً لزيارتكم") ?: "") }
    var socialLinks by remember { mutableStateOf(prefs.getString("ticket_social", "") ?: "") }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text("معلومات التذكرة 🎫", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedTextField(value = welcomeMsg, onValueChange = { welcomeMsg = it }, label = { Text("رسالة الترحيب") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = footerMsg, onValueChange = { footerMsg = it }, label = { Text("تذييل التذكرة") }, modifier = Modifier.fillMaxWidth().height(100.dp), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = socialLinks, onValueChange = { socialLinks = it }, label = { Text("شبكات التواصل الاجتماعي") }, modifier = Modifier.fillMaxWidth().height(100.dp), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PrimaryAppButton(text = "حفظ 💾", modifier = Modifier.weight(1f), containerColor = AppTheme.PremiumGold, contentColor = Color.White) {
                        prefs.edit().putString("ticket_welcome", welcomeMsg).putString("ticket_footer", footerMsg).putString("ticket_social", socialLinks).apply()
                        Toast.makeText(context, "تم الحفظ", Toast.LENGTH_SHORT).show(); onBack()
                    }
                    SecondaryAppButton(text = "رجوع", isDark = isDark, modifier = Modifier.weight(1f)) { onBack() }
                }
            }
        }
    }
}
// ==========================================
// 3️⃣ إعدادات أخرى (محدثة مع زر تسجيل الخروج الفعّال 100%)
// ==========================================
@Composable
fun OtherSettingsSubScreen(
    isDark: Boolean,
    inventoryManager: InventoryManager,
    onThemeChange: (Boolean) -> Unit,
    onDataChanged: () -> Unit = {},
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val prefs = SessionStore.currentStorePrefs(context)

    var showResetTransactionsDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text("إعدادات أخرى 🎛️", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // المظهر العام
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column { Text("المظهر العام", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark)); Text("تغيير ألوان التطبيق", fontSize = 11.sp, color = AppTheme.subText(isDark)) }
                    SecondaryAppButton(text = if (isDark) "نهاري ☀️" else "ليلي 🌙", isDark = isDark) { onThemeChange(!isDark) }
                }

                HorizontalDivider(color = AppTheme.inputBg(isDark), modifier = Modifier.padding(vertical = 8.dp))

                // إدارة البيانات والتصفير
                Text("إدارة البيانات ⚠️", fontWeight = FontWeight.Bold, color = AppTheme.ColorDanger)
                Button(
                    onClick = { showResetTransactionsDialog = true },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AppTheme.ColorDanger),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حذف بيانات المبيعات والفواتير نهائياً", color = Color.White, fontWeight = FontWeight.Bold)
                }

                HorizontalDivider(color = AppTheme.inputBg(isDark), modifier = Modifier.padding(vertical = 8.dp))

                // 🚀 زر تسجيل الخروج
                Text("الحساب 👤", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
                Button(
                    onClick = { showLogoutDialog = true },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    border = BorderStroke(1.dp, AppTheme.ColorDanger),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, tint = AppTheme.ColorDanger)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تسجيل الخروج من الحساب", color = AppTheme.ColorDanger, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // 🔴 نافذة تأكيد تصفير البيانات
    if (showResetTransactionsDialog) {
        AlertDialog(
            onDismissRequest = { showResetTransactionsDialog = false },
            containerColor = AppTheme.card(isDark),
            shape = RoundedCornerShape(16.dp),
            title = { Text("تأكيد التصفير ⚠️", fontWeight = FontWeight.Bold, color = AppTheme.ColorDanger) },
            text = { Text("سيتم حذف جميع المبيعات والمصروفات وأرشيف الفواتير نهائياً من الجهاز والخادم. لن يتم حذف المنتجات أو العملاء. يجب توفر الإنترنت لإتمام الحذف بشكل نهائي.", color = AppTheme.text(isDark), fontSize = 14.sp, lineHeight = 22.sp) },
                        confirmButton = {
                Button(
                    onClick = {
                        showResetTransactionsDialog = false

                        inventoryManager.resetDailyDataAsync(
                            onSuccess = {
                                prefs.edit().remove("transactions_data").apply()
                                showResetTransactionsDialog = false
                                onDataChanged()
                                Toast.makeText(context, "تم حذف المبيعات والفواتير والمصروفات نهائياً.", Toast.LENGTH_LONG).show()
                            },
                            onFailure = { error ->
                                Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppTheme.ColorDanger)
                ) { Text("نعم، حذف نهائياً", color = Color.White, fontWeight = FontWeight.Bold) }
            },

            dismissButton = { TextButton(onClick = { showResetTransactionsDialog = false }) { Text("إلغاء", color = AppTheme.subText(isDark)) } }
        )
    }

    // 🔴 نافذة تأكيد تسجيل الخروج (بالتحديث النهائي والجذري)
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            containerColor = AppTheme.card(isDark),
            shape = RoundedCornerShape(16.dp),
            title = { Text("تسجيل الخروج 🚪", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark)) },
            text = { Text("هل أنت متأكد أنك تريد تسجيل الخروج والعودة لشاشة الدخول؟", color = AppTheme.subText(isDark), fontSize = 14.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false

                        // إيقاف مزامنة المتجر ومسح ذاكرة الجلسة قبل تسجيل الخروج.
                        inventoryManager.clearSession()
                        AuthManager(context).logout()
                        Toast.makeText(context, "تم تسجيل الخروج بنجاح! 🔒", Toast.LENGTH_SHORT).show()

                        // 2. الانتقال إلى الشاشة الرئيسية بمسار نظيف تماماً ومسح كل الواجهات السابقة
                        val intent = android.content.Intent(context, MainActivity::class.java).apply {
                            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
                        }
                        context.startActivity(intent)

                        // 3. إغلاق الـ Activity الحالية لضمان عدم بقاء أي Compose State
                        (context as? android.app.Activity)?.finish()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppTheme.ColorDanger)
                ) { Text("نعم، خروج", color = Color.White, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showLogoutDialog = false }) { Text("إلغاء", color = AppTheme.subText(isDark)) } }
        )
    }
}

// ==========================================
// 4️⃣ شاشة النسخ الاحتياطي
// ==========================================
@Composable
fun BackupSubScreen(inventoryManager: InventoryManager, isDark: Boolean, onDataChanged: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { try { val json = inventoryManager.exportToJson(); context.contentResolver.openOutputStream(it)?.use { out -> out.write(json.toByteArray()) }; Toast.makeText(context, "تم الحفظ بنجاح!", Toast.LENGTH_LONG).show() } catch (e: Exception) { Toast.makeText(context, "فشل الحفظ!", Toast.LENGTH_SHORT).show() } }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { try { val jsonStr = context.contentResolver.openInputStream(it)?.bufferedReader()?.use { reader -> reader.readText() }; if (jsonStr != null && inventoryManager.importFromJson(jsonStr)) { onDataChanged(); Toast.makeText(context, "تم الاستعادة", Toast.LENGTH_LONG).show() } else { Toast.makeText(context, "ملف غير صالح!", Toast.LENGTH_SHORT).show() } } catch (e: Exception) { Toast.makeText(context, "فشل الاستعادة!", Toast.LENGTH_SHORT).show() } }
    }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text("النسخ الاحتياطي 💾", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
        }
        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("نسخ احتياطي واستعادة", color = AppTheme.GoldPrimary, fontWeight = FontWeight.Bold)
                PrimaryAppButton(text = "حفظ نسخة احتياطية الآن (تصدير)", modifier = Modifier.fillMaxWidth(), containerColor = AppTheme.PremiumGold, contentColor = Color.White) { backupLauncher.launch("Kasebo_Backup.json") }
                SecondaryAppButton(text = "استعادة بيانات من ملف (استيراد)", isDark = isDark, modifier = Modifier.fillMaxWidth()) { restoreLauncher.launch(arrayOf("application/json", "*/*")) }
            }
        }
    }
}

// ==========================================
// 5️⃣ شاشة معلومات الشركة
// ==========================================
@Composable
fun CompanyInfoSubScreen(isDark: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    val companyManager = remember { CompanyInfoManager(context) }
    val savedInfo = remember { companyManager.getCompanyInfo() }

    var name by remember { mutableStateOf(savedInfo.name) }
    var activity by remember { mutableStateOf(savedInfo.activity) }
    var address by remember { mutableStateOf(savedInfo.address) }
    var phoneFax by remember { mutableStateOf(savedInfo.phoneFax) }
    var rcNumber by remember { mutableStateOf(savedInfo.rcNumber) }
    var nifNumber by remember { mutableStateOf(savedInfo.nifNumber) }
    var articleNumber by remember { mutableStateOf(savedInfo.articleNumber) }
    var logoBase64 by remember { mutableStateOf(savedInfo.logoBase64) }

    val imagePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? -> uri?.let { logoBase64 = uriToBase64(context, it); Toast.makeText(context, "تم إرفاق الشعار", Toast.LENGTH_SHORT).show() } }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text("معلومات المؤسسة 🏢", color = AppTheme.text(isDark), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), border = BorderStroke(1.dp, AppTheme.cardBorder(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم المؤسسة") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = activity, onValueChange = { activity = it }, label = { Text("نشاط المؤسسة") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = phoneFax, onValueChange = { phoneFax = it }, label = { Text("الهاتف") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), border = BorderStroke(1.dp, AppTheme.cardBorder(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = rcNumber, onValueChange = { rcNumber = it }, label = { Text("رقم السجل التجاري") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = nifNumber, onValueChange = { nifNumber = it }, label = { Text("الرقم الضريبي") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = articleNumber, onValueChange = { articleNumber = it }, label = { Text("رقم المادة") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), border = BorderStroke(1.dp, AppTheme.cardBorder(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("شعار المؤسسة", color = AppTheme.GoldPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                Box(modifier = Modifier.size(120.dp).clip(RoundedCornerShape(16.dp)).background(AppTheme.inputBg(isDark)).clickable { imagePickerLauncher.launch("image/*") }, contentAlignment = Alignment.Center) {
                    if (logoBase64.isNotBlank()) Text("تم الشعار ✓", color = AppTheme.ColorSuccess) else Icon(Icons.Default.Image, null, tint = AppTheme.subText(isDark), modifier = Modifier.size(40.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { logoBase64 = "" }, colors = ButtonDefaults.buttonColors(containerColor = AppTheme.ColorDanger)) { Text("حذف") }
                    Button(onClick = { imagePickerLauncher.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = AppTheme.PremiumGold)) { Text("صورة") }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PrimaryAppButton(text = "حفظ", modifier = Modifier.weight(1f), containerColor = AppTheme.PremiumGold, contentColor = Color.White) {
                companyManager.saveCompanyInfo(CompanyInfo(name, activity, address, phoneFax, rcNumber, nifNumber, articleNumber, logoBase64))
                Toast.makeText(context, "تم الحفظ", Toast.LENGTH_SHORT).show(); onBack()
            }
            SecondaryAppButton(text = "رجوع", isDark = isDark, modifier = Modifier.weight(1f)) { onBack() }
        }
        Spacer(Modifier.height(40.dp))
    }
}

// ==========================================
// 6️⃣ شاشة إدارة الفئات والوحدات
// ==========================================
@Composable
fun ListManagerSubScreen(title: String, subtitle: String, desc: String, inputLabel: String, prefsKey: String, defaultItems: String, isDark: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = SessionStore.currentStorePrefs(context)

    var items by remember { mutableStateOf(prefs.getString(prefsKey, defaultItems)?.split(",")?.filter { it.isNotBlank() } ?: emptyList()) }
    var inputValue by remember { mutableStateOf("") }

    fun saveItems(newList: List<String>) { items = newList; prefs.edit().putString(prefsKey, newList.joinToString(",")).apply() }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text(title, color = AppTheme.text(isDark), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Build, null, tint = AppTheme.PremiumGold, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(8.dp))
                Text(subtitle, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark), fontSize = 16.sp)
                Text(desc, color = AppTheme.subText(isDark), fontSize = 12.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = inputValue, onValueChange = { inputValue = it }, label = { Text(inputLabel) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                Button(onClick = { if (inputValue.isNotBlank() && !items.contains(inputValue)) { saveItems(items + inputValue); inputValue = ""; Toast.makeText(context, "تمت الإضافة", Toast.LENGTH_SHORT).show() } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = AppTheme.PremiumGold)) { Text("إضافة 💾") }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("القائمة", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
                    Surface(color = AppTheme.PremiumGold.copy(alpha = 0.2f), shape = RoundedCornerShape(16.dp)) { Text("المجموع ${items.size}", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = AppTheme.PremiumGold, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(16.dp))
                items.forEachIndexed { index, item ->
                    Card(colors = CardDefaults.cardColors(containerColor = AppTheme.bg(isDark)), border = BorderStroke(1.dp, AppTheme.cardBorder(isDark)), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(item, color = AppTheme.text(isDark), fontWeight = FontWeight.Bold); Text("#${index + 1}", color = AppTheme.subText(isDark)) }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { saveItems(items.filter { it != item }) }, modifier = Modifier.weight(1f).height(35.dp), colors = ButtonDefaults.buttonColors(containerColor = AppTheme.ColorDanger.copy(alpha = 0.2f)), contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.Delete, null, tint = AppTheme.ColorDanger, modifier = Modifier.size(16.dp)) }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

// ==========================================
// 7️⃣ شاشة كلمات المرور (فعالة 100%)
// ==========================================
@Composable
fun PasswordsSubScreen(isDark: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = SessionStore.currentStorePrefs(context)

    LaunchedEffect(Unit) { LocalCredentialStore.migrateLegacyPlaintext(context) }
    var usersVersion by remember { mutableIntStateOf(0) }
    val usersMap = remember(usersVersion) { LocalCredentialStore.users(context).associateWith { "••••••" } }

    var selectedUser by remember { mutableStateOf(usersMap.keys.firstOrNull() ?: "") }
    var currentPwd by remember { mutableStateOf("") }
    var newPwd by remember { mutableStateOf("") }
    var confirmPwd by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text("كلمة المرور 🔑", color = AppTheme.text(isDark), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), border = BorderStroke(1.dp, AppTheme.GoldPrimary.copy(alpha = 0.35f)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("معرّف المدير", color = AppTheme.GoldPrimary, fontWeight = FontWeight.Bold)
                Text("admin", color = AppTheme.text(isDark), fontSize = 16.sp, fontWeight = FontWeight.Black)
                val adminEmail = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email.orEmpty()
                if (adminEmail.isNotBlank()) Text("حساب Firebase: $adminEmail", color = AppTheme.subText(isDark), fontSize = 11.sp)
                Text("كلمة المرور لا يمكن عرضها أو استرجاعها. يمكن تغييرها فقط عبر التحقق من كلمة المرور الحالية.", color = AppTheme.subText(isDark), fontSize = 11.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.ColorDanger.copy(alpha = 0.1f)), border = BorderStroke(1.dp, AppTheme.ColorDanger.copy(alpha = 0.3f)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Warning, null, tint = AppTheme.ColorDanger); Spacer(Modifier.width(8.dp)); Text("مهم", color = AppTheme.ColorDanger, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(4.dp))
                Text("إذا كانت كلمة مرور المدير admin، يرجى تغييرها لحماية حسابك.", color = AppTheme.ColorDanger, fontSize = 12.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SafeDropdownSelector("المستخدم", usersMap.keys.toList(), selectedUser, { selectedUser = it }, isDark)
                OutlinedTextField(value = currentPwd, onValueChange = { currentPwd = it }, label = { Text("كلمة المرور الحالية") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = newPwd, onValueChange = { newPwd = it }, label = { Text("كلمة المرور الجديدة") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = confirmPwd, onValueChange = { confirmPwd = it }, label = { Text("تأكيد كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))

                Button(
                    onClick = {
                        if(newPwd == confirmPwd && newPwd.length >= 6) {
                            if (LocalCredentialStore.verify(context, selectedUser, currentPwd)) {
                                LocalCredentialStore.setPassword(context, selectedUser, newPwd)
                                usersVersion++
                                currentPwd = ""; newPwd = ""; confirmPwd = ""
                                Toast.makeText(context, "تم التغيير بنجاح", Toast.LENGTH_SHORT).show()
                            } else { Toast.makeText(context, "كلمة المرور الحالية خاطئة", Toast.LENGTH_SHORT).show() }
                        } else { Toast.makeText(context, "يجب أن تتطابق كلمة المرور الجديدة وألا تقل عن 6 أحرف", Toast.LENGTH_SHORT).show() }
                    },
                    modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = AppTheme.PremiumGold)
                ) { Text("حفظ التغييرات 💾") }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("قائمة المستخدمين", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
                    Surface(color = AppTheme.AccentSky.copy(alpha = 0.2f), shape = RoundedCornerShape(16.dp)) { Text("المجموع ${usersMap.size}", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = AppTheme.AccentSky, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                }
                usersMap.keys.forEach { user ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Person, null, tint = AppTheme.subText(isDark), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(user, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark)) }
                        Button(onClick = { selectedUser = user }, colors = ButtonDefaults.buttonColors(containerColor = AppTheme.AccentSky)) { Text("تغيير السر") }
                    }
                    HorizontalDivider(color = AppTheme.inputBg(isDark))
                }
            }
        }
    }
}

// ==========================================
// 8️⃣ شاشة المستخدمين (فعالة 100%)
// ==========================================
@Composable
fun UsersSubScreen(isDark: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = SessionStore.currentStorePrefs(context)

    LaunchedEffect(Unit) { LocalCredentialStore.migrateLegacyPlaintext(context) }
    var usersVersion by remember { mutableIntStateOf(0) }
    var rolesStr by remember { mutableStateOf(prefs.getString("app_roles", "{\"admin\":\"مدير\"}") ?: "{\"admin\":\"مدير\"}") }

    val usersMap = remember(usersVersion) { LocalCredentialStore.users(context).associateWith { "••••••" } }
    val rolesMap = remember(rolesStr) { val map = mutableMapOf<String, String>(); try { val json = JSONObject(rolesStr); json.keys().forEach { map[it] = json.getString(it) } } catch (e: Exception) {}; map }

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var userToDelete by remember { mutableStateOf<String?>(null) }

    var selectedUserForRole by remember { mutableStateOf(usersMap.keys.firstOrNull() ?: "") }
    var selectedRole by remember { mutableStateOf(rolesMap[selectedUserForRole] ?: "كاشير") }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text("المستخدمون والصلاحيات 👥", color = AppTheme.text(isDark), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("إضافة مستخدم ➕", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold)
                OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))

                Button(
                    onClick = {
                        val cleanUsername = username.trim()
                        val cleanPassword = password.trim()
                        if(cleanUsername.isBlank() || cleanPassword.length < 6) {
                            Toast.makeText(context, "أدخل اسم المستخدم وكلمة مرور من 6 أحرف على الأقل", Toast.LENGTH_LONG).show()
                        } else if (usersMap.containsKey(cleanUsername)) {
                            Toast.makeText(context, "اسم المستخدم موجود مسبقاً", Toast.LENGTH_SHORT).show()
                        } else {
                            LocalCredentialStore.setPassword(context, cleanUsername, cleanPassword)
                            val rJson = JSONObject(rolesStr); rJson.put(cleanUsername, "كاشير")
                            prefs.edit().putString("app_roles", rJson.toString()).apply()
                            rolesStr = rJson.toString(); usersVersion++
                            username = ""; password = ""
                            Toast.makeText(context, "تمت إضافة المستخدم", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.align(Alignment.End), colors = ButtonDefaults.buttonColors(containerColor = AppTheme.PremiumGold)
                ) { Text("إضافة مستخدم") }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("الحقوق والصلاحيات 🛡️", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
                Text("تحديد مستوى الوصول والصلاحية للمستخدمين.", fontSize = 12.sp, color = AppTheme.subText(isDark))

                SafeDropdownSelector("المستخدم المراد تهيئته", usersMap.keys.toList(), selectedUserForRole, { selectedUserForRole = it; selectedRole = rolesMap[it] ?: "كاشير" }, isDark)
                SafeDropdownSelector("الصلاحية والمستوى", listOf("مدير", "كاشير"), selectedRole, { selectedRole = it }, isDark)

                Button(
                    onClick = {
                        val rJson = JSONObject(rolesStr)
                        rJson.put(selectedUserForRole, selectedRole)
                        prefs.edit().putString("app_roles", rJson.toString()).apply()
                        if (selectedUserForRole == "admin" || selectedUserForRole == SessionStore.uid(context)) {
                            prefs.edit().putString("user_role", if (selectedRole == "مدير") "Admin" else "Cashier").apply()
                        }
                        rolesStr = rJson.toString()
                        Toast.makeText(context, "تم تحديث الصلاحيات", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = AppTheme.PremiumGold)
                ) { Text("حفظ الصلاحيات 💾") }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("إدارة المستخدمين", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
                Text("يمكن للمدير حذف المستخدم المحلي. لا يمكن حذف حساب المدير الرئيسي من هنا.", fontSize = 12.sp, color = AppTheme.subText(isDark))
                usersMap.keys.forEach { user ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(user, color = AppTheme.text(isDark), fontWeight = FontWeight.SemiBold)
                        if (user != "admin") {
                            OutlinedButton(onClick = { userToDelete = user }, border = BorderStroke(1.dp, AppTheme.ColorDanger)) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = AppTheme.ColorDanger)
                                Spacer(Modifier.width(4.dp))
                                Text("حذف المستخدم", color = AppTheme.ColorDanger)
                            }
                        } else {
                            Text("المدير الرئيسي", color = AppTheme.GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    userToDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            containerColor = AppTheme.card(isDark),
            title = { Text("حذف المستخدم", color = AppTheme.ColorDanger, fontWeight = FontWeight.Bold) },
            text = { Text("سيتم حذف المستخدم المحلي \"$target\" وكلمة مروره المحفوظة والصلاحية المحلية. لا يمكن التراجع عن هذا الإجراء.", color = AppTheme.text(isDark)) },
            confirmButton = {
                TextButton(onClick = {
                    LocalCredentialStore.removeUser(context, target)
                    val rJson = JSONObject(rolesStr)
                    rJson.remove(target)
                    rolesStr = rJson.toString()
                    prefs.edit().putString("app_roles", rolesStr).apply()
                    if (selectedUserForRole == target) {
                        selectedUserForRole = LocalCredentialStore.users(context).firstOrNull() ?: ""
                        selectedRole = rolesMap[selectedUserForRole] ?: "كاشير"
                    }
                    usersVersion++
                    userToDelete = null
                    Toast.makeText(context, "تم حذف المستخدم", Toast.LENGTH_SHORT).show()
                }) { Text("حذف نهائي", color = AppTheme.ColorDanger, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { userToDelete = null }) { Text("إلغاء", color = AppTheme.subText(isDark)) } }
        )
    }
}

// ==========================================
// 9️⃣ شاشة تدقيق الجرد
// ==========================================
@Composable
fun AuditSubScreen(isDark: Boolean, onBack: () -> Unit) {
    var searchLog by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppTheme.text(isDark)) }
            Text("تدقيق الجرد 📋", color = AppTheme.text(isDark), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = searchLog, onValueChange = { searchLog = it }, label = { Text("بحث (الجلسة، الكود، المنتج...)") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) { OutlinedTextField(value = "", onValueChange = {}, label = { Text("تاريخ البداية") }, enabled = false, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark)) }
                    Box(modifier = Modifier.weight(1f)) { OutlinedTextField(value = "", onValueChange = {}, label = { Text("تاريخ النهاية") }, enabled = false, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = getSettingsFieldColors(isDark)) }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("السطور", color = AppTheme.subText(isDark)); Text("0", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark), fontSize = 18.sp) }
                HorizontalDivider(color = AppTheme.inputBg(isDark))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("الجلسات", color = AppTheme.subText(isDark)); Text("0", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark), fontSize = 18.sp) }
                HorizontalDivider(color = AppTheme.inputBg(isDark))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("فرق الكمية", color = AppTheme.subText(isDark)); Text("0", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark), fontSize = 18.sp) }
                HorizontalDivider(color = AppTheme.inputBg(isDark))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("قيمة الفرق", color = AppTheme.subText(isDark)); Text("0.00 DA", fontWeight = FontWeight.Black, color = Color(0xFF1E3A8A), fontSize = 20.sp) }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(12.dp).fillMaxWidth()) {
                Text("المستخدم", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("الجلسة", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                Text("التاريخ", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), modifier = Modifier.fillMaxWidth()) {
            Text("لا توجد سجلات جرد محفوظة حالياً.", color = AppTheme.subText(isDark), modifier = Modifier.padding(24.dp).align(Alignment.CenterHorizontally))
        }
        Spacer(Modifier.height(40.dp))
    }
}
