package com.example.bookstoremanager.ui

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bookstoremanager.AppTheme
import com.example.bookstoremanager.data.InventoryManager
import com.example.bookstoremanager.data.formatClean
import com.example.bookstoremanager.data.toDzd
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class ExportType(val label: String) {
    SALES("المبيعات"),
    FINANCE("الملخص المالي"),
    STOCK("المخزون")
}

private data class ReportRange(val start: Long?, val end: Long?, val label: String)

@Composable
fun ReportsExportScreen(inventoryManager: InventoryManager, isDark: Boolean, onBack: () -> Unit) {
    val context = LocalContext.current
    var exportType by remember { mutableStateOf(ExportType.SALES) }
    var rangeMode by remember { mutableStateOf("month") }
    var customStart by remember { mutableLongStateOf(startOfMonth()) }
    var customEnd by remember { mutableLongStateOf(endOfDay(System.currentTimeMillis())) }

    val range = remember(rangeMode, customStart, customEnd) {
        when (rangeMode) {
            "today" -> ReportRange(startOfDay(System.currentTimeMillis()), endOfDay(System.currentTimeMillis()), "اليوم")
            "yesterday" -> {
                val yesterday = System.currentTimeMillis() - 24L * 60 * 60 * 1000
                ReportRange(startOfDay(yesterday), endOfDay(yesterday), "أمس")
            }
            "7days" -> ReportRange(startOfDay(System.currentTimeMillis() - 6L * 24 * 60 * 60 * 1000), endOfDay(System.currentTimeMillis()), "آخر 7 أيام")
            "30days" -> ReportRange(startOfDay(System.currentTimeMillis() - 29L * 24 * 60 * 60 * 1000), endOfDay(System.currentTimeMillis()), "آخر 30 يومًا")
            "month" -> ReportRange(startOfMonth(), endOfDay(System.currentTimeMillis()), "هذا الشهر")
            "lastmonth" -> {
                val c = Calendar.getInstance().apply { add(Calendar.MONTH, -1) }
                ReportRange(startOfMonth(c.timeInMillis), endOfMonth(c.timeInMillis), "الشهر الماضي")
            }
            "year" -> ReportRange(startOfYear(), endOfDay(System.currentTimeMillis()), "هذا العام")
            "all" -> ReportRange(null, null, "كل الفترة")
            else -> ReportRange(customStart, customEnd, "نطاق مخصص")
        }
    }

    val sales = inventoryManager.getSalesHistory().filter { inRange(it.timestamp, range.start, range.end) }.sortedByDescending { it.timestamp }
    val products = inventoryManager.getProductList()
    val salesTotal = sales.sumOf { it.revenue }
    val profitTotal = sales.sumOf { it.profit }

    fun handleSavedUri(uri: Uri?, mimeType: String) {
        if (uri != null) {
            try {
                when (mimeType) {
                    "text/csv" -> {
                        writeText(context, uri, buildCsv(exportType, range, sales, products, salesTotal, profitTotal))
                    }
                    "application/pdf" -> {
                        writePdf(context, uri, buildReportText(exportType, range, sales, products, salesTotal, profitTotal), exportType.label)
                    }
                }
                shareFile(context, uri, mimeType)
                Toast.makeText(context, "تم حفظ التقرير وتجهيزه للمشاركة", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "فشل حفظ التقرير: ${e.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
            }
        }
    }

    val csvSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        handleSavedUri(uri, "text/csv")
    }
    val pdfSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        handleSavedUri(uri, "application/pdf")
    }

    Column(
        modifier = Modifier.fillMaxSize().background(AppTheme.bg(isDark)).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().statusBarsPadding(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "عودة", tint = AppTheme.text(isDark)) }
            Column(horizontalAlignment = Alignment.End) {
                Text("تصدير ومشاركة التقارير", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
                Text("PDF و CSV مع فلترة موحدة بالتاريخ", fontSize = 12.sp, color = AppTheme.subText(isDark))
            }
        }

        Text("نوع التقرير", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            ExportType.values().forEach { type ->
                FilterChip(selected = exportType == type, onClick = { exportType = type }, label = { Text(type.label) }, modifier = Modifier.weight(1f))
            }
        }

        Text("الفترة الزمنية", color = AppTheme.text(isDark), fontWeight = FontWeight.Bold)
        Card(
            colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DateRange, null, tint = AppTheme.GoldPrimary, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("اختيار سريع", fontWeight = FontWeight.Bold, color = AppTheme.text(isDark))
                        Text("حدد الفترة التي تريد تصديرها أو مشاركتها", fontSize = 11.sp, color = AppTheme.subText(isDark))
                    }
                }
                val quickRanges = listOf(
                    "today" to "اليوم",
                    "yesterday" to "أمس",
                    "7days" to "آخر 7 أيام",
                    "30days" to "آخر 30 يومًا",
                    "month" to "هذا الشهر",
                    "lastmonth" to "الشهر الماضي",
                    "year" to "هذا العام",
                    "all" to "كل الفترة"
                )
                quickRanges.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (key, label) ->
                            val selected = rangeMode == key
                            OutlinedButton(
                                onClick = { rangeMode = key },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (selected) AppTheme.GoldPrimary.copy(alpha = 0.12f) else Color.Transparent,
                                    contentColor = if (selected) AppTheme.GoldPrimary else AppTheme.text(isDark)
                                ),
                                            ) { Text(label, fontSize = 12.sp, maxLines = 1) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                OutlinedButton(
                    onClick = { rangeMode = "custom" },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (rangeMode == "custom") AppTheme.GoldPrimary.copy(alpha = 0.12f) else Color.Transparent,
                        contentColor = if (rangeMode == "custom") AppTheme.GoldPrimary else AppTheme.text(isDark)
                    ),
                    ) {
                    Icon(Icons.Default.Event, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(if (rangeMode == "custom") customRangeLabel(customStart, customEnd) else "تحديد فترة مخصصة")
                }

                if (rangeMode == "custom") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showDatePicker(context, customStart) { selected ->
                                val start = startOfDay(selected)
                                customStart = start
                                if (customEnd < start) customEnd = endOfDay(start)
                            } },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("من: ${formatShortDate(customStart)}", fontSize = 11.sp) }
                        OutlinedButton(
                            onClick = { showDatePicker(context, customEnd) { selected ->
                                val end = endOfDay(selected)
                                if (end >= customStart) customEnd = end
                            } },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("إلى: ${formatShortDate(customEnd)}", fontSize = 11.sp) }
                    }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = AppTheme.card(isDark)), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ملخص النطاق: ${range.label}", color = AppTheme.GoldPrimary, fontWeight = FontWeight.Bold)
                Text("المبيعات: ${salesTotal.toDzd()}", color = AppTheme.text(isDark))
                Text("الربح: ${profitTotal.toDzd()}", color = AppTheme.ColorSuccess, fontWeight = FontWeight.Bold)
                Text("عدد سجلات البيع: ${sales.size}", color = AppTheme.subText(isDark))
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { csvSaveLauncher.launch("Kasebo_${exportType.label}_${System.currentTimeMillis()}.csv") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AppTheme.ColorSuccess)) {
                Icon(Icons.Default.TableChart, null); Spacer(Modifier.width(6.dp)); Text("CSV")
            }
            Button(onClick = { pdfSaveLauncher.launch("Kasebo_${exportType.label}_${System.currentTimeMillis()}.pdf") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AppTheme.GoldPrimary)) {
                Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(6.dp)); Text("PDF")
            }
        }

        Text("بعد الحفظ يمكنك مشاركة الملف من تطبيق الملفات. ملفات CSV تستخدم UTF-8 مع BOM لدعم العربية في Excel.", color = AppTheme.subText(isDark), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(30.dp))
    }
}

private fun showDatePicker(context: Context, initial: Long, onSelected: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { timeInMillis = initial }
    DatePickerDialog(context, { _, year, month, day ->
        onSelected(Calendar.getInstance().apply { set(year, month, day, 12, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis)
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

private fun startOfDay(time: Long): Long = Calendar.getInstance().apply { timeInMillis = time; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
private fun endOfDay(time: Long): Long = Calendar.getInstance().apply { timeInMillis = time; set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }.timeInMillis
private fun startOfMonth(): Long = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }.let { startOfDay(it.timeInMillis) }
private fun startOfMonth(time: Long): Long = Calendar.getInstance().apply { timeInMillis = time; set(Calendar.DAY_OF_MONTH, 1) }.let { startOfDay(it.timeInMillis) }
private fun endOfMonth(time: Long): Long = Calendar.getInstance().apply { timeInMillis = time; set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH)) }.let { endOfDay(it.timeInMillis) }
private fun startOfYear(): Long = Calendar.getInstance().apply { set(Calendar.MONTH, Calendar.JANUARY); set(Calendar.DAY_OF_MONTH, 1) }.let { startOfDay(it.timeInMillis) }
private fun formatShortDate(time: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(time))
private fun inRange(time: Long, start: Long?, end: Long?): Boolean = (start == null || time >= start) && (end == null || time <= end)
private fun customRangeLabel(start: Long, end: Long): String = "${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(start))} → ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(end))}"

private fun buildCsv(type: ExportType, range: ReportRange, sales: List<com.example.bookstoremanager.data.SaleRecord>, products: List<com.example.bookstoremanager.data.Product>, salesTotal: Double, profitTotal: Double): String {
    val sb = StringBuilder("\uFEFF")
    sb.append("تقرير Kasebo,${type.label}\n")
    sb.append("الفترة,${range.label}\n")
    when (type) {
        ExportType.SALES -> {
            sb.append("المعرف,الفاتورة,المنتج,الكمية,الإيراد,الربح,الموظف UID,التاريخ\n")
            sales.forEach { sale -> sb.append(row(listOf(sale.saleId, sale.invoiceId, sale.productName, sale.quantity.formatClean(), sale.revenue.formatClean(), sale.profit.formatClean(), sale.staffUid, formatDate(sale.timestamp)))) }
            sb.append(row(listOf("الإجمالي", "", "", "", salesTotal.formatClean(), profitTotal.formatClean(), "", "")))
        }
        ExportType.FINANCE -> {
            sb.append("المؤشر,القيمة\n")
            sb.append(row(listOf("إجمالي المبيعات", salesTotal.toDzd())))
            sb.append(row(listOf("إجمالي الربح", profitTotal.toDzd())))
            sb.append(row(listOf("عدد عمليات البيع", sales.size.toString())))
            sb.append(row(listOf("قيمة المخزون الحالية", inventoryValue(products).toDzd())))
        }
        ExportType.STOCK -> {
            sb.append("المعرف,المنتج,الباركود,التصنيف,الكمية,سعر الشراء,سعر البيع,قيمة المخزون\n")
            products.sortedBy { it.name.lowercase(Locale.getDefault()) }.forEach { p -> sb.append(row(listOf(p.id, p.name, p.barcode, p.category, p.stockQuantity.formatClean(), p.purchasePrice.formatClean(), p.sellingPrice.formatClean(), (p.stockQuantity * p.purchasePrice).formatClean()))) }
        }
    }
    return sb.toString()
}

private fun row(values: List<String>): String = values.joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" } + "\n"
private fun formatDate(time: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(time))
private fun inventoryValue(products: List<com.example.bookstoremanager.data.Product>): Double = products.sumOf { it.stockQuantity * it.purchasePrice }

private fun buildReportText(type: ExportType, range: ReportRange, sales: List<com.example.bookstoremanager.data.SaleRecord>, products: List<com.example.bookstoremanager.data.Product>, salesTotal: Double, profitTotal: Double): String {
    val lines = mutableListOf("الفترة: ${range.label}", "تاريخ التصدير: ${formatDate(System.currentTimeMillis())}", "")
    when (type) {
        ExportType.SALES -> {
            lines += "إجمالي المبيعات: ${salesTotal.toDzd()}"
            lines += "إجمالي الربح: ${profitTotal.toDzd()}"
            lines += "عدد السجلات: ${sales.size}"
            lines += ""
            sales.take(200).forEach { lines += "${formatDate(it.timestamp)} | ${it.productName} | كمية ${it.quantity.formatClean()} | ${it.revenue.toDzd()} | الموظف: ${it.staffUid.ifBlank { "غير مسجل" }}" }
        }
        ExportType.FINANCE -> {
            lines += "إجمالي المبيعات: ${salesTotal.toDzd()}"
            lines += "إجمالي الربح: ${profitTotal.toDzd()}"
            lines += "عدد عمليات البيع: ${sales.size}"
            lines += "قيمة المخزون الحالية: ${inventoryValue(products).toDzd()}"
        }
        ExportType.STOCK -> {
            lines += "عدد المنتجات: ${products.size}"
            lines += "قيمة المخزون: ${inventoryValue(products).toDzd()}"
            lines += ""
            products.take(200).forEach { lines += "${it.name} | كمية ${it.stockQuantity.formatClean()} | شراء ${it.purchasePrice.toDzd()} | بيع ${it.sellingPrice.toDzd()}" }
        }
    }
    return lines.joinToString("\n")
}

private fun shareFile(context: Context, uri: Uri, mimeType: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة التقرير"))
}

private fun writeText(context: Context, uri: Uri, text: String) {
    context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: error("تعذر فتح الملف")
}

private fun writePdf(context: Context, uri: Uri, content: String, title: String) {
    val document = PdfDocument()
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; color = android.graphics.Color.BLACK; textAlign = Paint.Align.RIGHT }
    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 20f; color = android.graphics.Color.BLACK; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    var pageNumber = 1
    var page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
    var canvas = page.canvas
    canvas.drawText("تقرير $title", 297.5f, 55f, titlePaint)
    var y = 95f
    content.split("\n").forEach { line ->
        if (y > 800f) { document.finishPage(page); pageNumber++; page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()); canvas = page.canvas; y = 55f }
        canvas.drawText(line.take(110), 555f, y, paint); y += 22f
    }
    document.finishPage(page)
    context.contentResolver.openOutputStream(uri)?.use { document.writeTo(it) } ?: error("تعذر فتح ملف PDF")
    document.close()
}
