package com.example.bookstoremanager.ui

import com.example.bookstoremanager.AppTheme

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.bookstoremanager.*
import com.example.bookstoremanager.data.*

@Composable
fun PasswordTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    isDark: Boolean
) {
    var passwordVisible by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = AppTheme.subText(isDark)) },
        leadingIcon = { Icon(Icons.Default.Lock, null, tint = AppTheme.subText(isDark)) },
        trailingIcon = {
            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                Text(text = if (passwordVisible) "👁️" else "🙈", fontSize = 16.sp)
            }
        },
        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = AppTheme.inputBg(isDark),
            unfocusedContainerColor = AppTheme.inputBg(isDark),
            focusedTextColor = AppTheme.text(isDark),
            unfocusedTextColor = AppTheme.text(isDark),
            focusedBorderColor = AppTheme.GoldPrimary,
            unfocusedBorderColor = Color.Transparent
        )
    )
}

@Composable
fun LoginAuthScreen(
    isDark: Boolean,
    onLoginSuccess: (String) -> Unit
) {
    val context = LocalContext.current

    val authManager = remember { AuthManager(context) }

    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var isSignUpMode by remember { mutableStateOf(false) }
    var isEmployeeJoinMode by remember { mutableStateOf(false) }
    var inviteToken by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = when { isEmployeeJoinMode -> "الانضمام كموظف 👤"; isSignUpMode -> "إنشاء متجر جديد 🚀"; else -> "تسجيل الدخول إلى كاسبو 🔑" },
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = AppTheme.text(isDark)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = when { isEmployeeJoinMode -> "أدخل بيانات حسابك ورمز الدعوة الذي أعطاك إياه صاحب المتجر:"; isSignUpMode -> "أدخل بريدك وكلمة السر لتسجيل حسابك وتوليد كود المتجر تلقائياً:"; else -> "أدخل بريدك الإلكتروني وكلمة السر للدخول إلى متجرك:" },
            color = AppTheme.subText(isDark),
            fontSize = 13.sp
        )

        Spacer(Modifier.height(20.dp))

        PremiumTextField(
            value = emailInput,
            onValueChange = { emailInput = it.trim() },
            label = "البريد الإلكتروني (Email)",
            isDark = isDark,
            icon = Icons.Default.Person
        )

        if (isEmployeeJoinMode) {
            Spacer(Modifier.height(12.dp))
            PremiumTextField(value = inviteToken, onValueChange = { inviteToken = it.uppercase() }, label = "رمز دعوة الموظف", isDark = isDark, icon = Icons.Default.Lock)
        }

        Spacer(Modifier.height(12.dp))

        PasswordTextField(
            value = passwordInput,
            onValueChange = { passwordInput = it },
            label = "كلمة السر (6 أرقام/أحرف على الأقل)",
            isDark = isDark
        )

        Spacer(Modifier.height(16.dp))

        if (isLoading) {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppTheme.GoldPrimary)
            }
        } else {
            PrimaryAppButton(
                text = if (isSignUpMode) "إنشاء الحساب وتوليد الكود ✨" else "تسجيل الدخول والمزامنة ☁️",
                modifier = Modifier.fillMaxWidth()
            ) {
                val cleanEmail = emailInput.trim()
                val cleanPassword = passwordInput.trim()

                if (cleanEmail.isBlank() || cleanPassword.length < 6) {
                    Toast.makeText(context, "يرجى كتابة البريد الإلكتروني وكلمة سر لا تقل عن 6 أحرف!", Toast.LENGTH_LONG).show()
                    return@PrimaryAppButton
                }

                isLoading = true

                if (isEmployeeJoinMode) {
                    authManager.registerEmployeeWithInvite(
                        email = cleanEmail,
                        pass = cleanPassword,
                        inviteToken = inviteToken,
                        onSuccess = { generatedStoreCode ->
                            isLoading = false
                            Toast.makeText(context, "تم ربط حسابك بالمتجر بنجاح ✅", Toast.LENGTH_LONG).show()
                            onLoginSuccess(generatedStoreCode)
                        },
                        onFailure = { errMsg ->
                            isLoading = false
                            Toast.makeText(context, "فشل الانضمام: $errMsg", Toast.LENGTH_LONG).show()
                        }
                    )
                } else if (isSignUpMode) {
                    authManager.registerNewStore(
                        email = cleanEmail,
                        pass = cleanPassword,
                        onSuccess = { generatedStoreCode ->
                            isLoading = false
                            onLoginSuccess(generatedStoreCode)
                        },
                        onFailure = { errMsg ->
                            isLoading = false
                            Toast.makeText(context, "فشل إنشاء الحساب: $errMsg", Toast.LENGTH_SHORT).show()
                        }
                    )
                } else {
                    authManager.loginStore(
                        email = cleanEmail,
                        pass = cleanPassword,
                        onSuccess = { storeCode ->
                            isLoading = false
                            Toast.makeText(context, "أهلاً بك مجدداً! تم الدخول بنجاح ✅", Toast.LENGTH_SHORT).show()
                            onLoginSuccess(storeCode)
                        },
                        onFailure = { err ->
                            isLoading = false
                            Toast.makeText(context, "فشل تسجيل الدخول: تأكد من الإيميل وكلمة السر", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            TextButton(
                onClick = {
                    isEmployeeJoinMode = false
                    isSignUpMode = !isSignUpMode
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isSignUpMode) "لديك حساب بالفعل؟ سجل الدخول هنا" else "ليس لديك متجر؟ اضغط هنا لإنشاء متجر جديد",
                    color = AppTheme.GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp
                )
            }
            TextButton(
                onClick = {
                    isEmployeeJoinMode = !isEmployeeJoinMode
                    isSignUpMode = false
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isEmployeeJoinMode) "العودة إلى تسجيل الدخول" else "لديك رمز دعوة موظف؟ انضم إلى متجر",
                    color = AppTheme.subText(isDark), fontWeight = FontWeight.Bold, fontSize = 12.sp
                )
            }

        }
    }
}
