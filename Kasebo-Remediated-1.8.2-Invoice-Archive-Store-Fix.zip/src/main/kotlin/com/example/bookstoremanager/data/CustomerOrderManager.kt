package com.example.bookstoremanager.data

import android.content.Context
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.auth.FirebaseAuth

/**
 * إدارة طلبات الزبائن السحابية.
 *
 * هذه الفئة متوافقة مع SaleRecord ذي الحقول المسماة في الإصدار 1.4.0،
 * وتحافظ على معرفات ثابتة للمبيعات الناتجة عن طلب واحد.
 */
class CustomerOrderManager(private val context: Context? = null) {

    // 🛒 إرسال الطلب من الزبون إلى قاعدة البيانات
    fun placeOrder(
        storeId: String,
        order: CustomerOrder,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        if (storeId.isBlank()) {
            onFailure("معرّف المتجر غير صالح")
            return
        }

        val databaseRef = FirebaseDatabase.getInstance()
            .getReference("Kasebo_Stores")
            .child(storeId)
            .child("orders")

        val orderId = "ORD-" + System.currentTimeMillis().toString().takeLast(6)
        val cleanOrder = order.copy(
            orderId = orderId,
            storeId = storeId,
            customerPhone = order.customerPhone.trim(),
            status = "New"
        )

        databaseRef.child(orderId).setValue(cleanOrder)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onFailure(e.message ?: "خطأ في إرسال الطلب")
            }
    }

    // 🔔 الاستماع لطلبات المتجر
    fun listenToStoreOrders(
        storeId: String,
        onOrdersUpdate: (List<CustomerOrder>) -> Unit
    ) {
        if (storeId.isBlank()) {
            onOrdersUpdate(emptyList())
            return
        }

        val databaseRef = FirebaseDatabase.getInstance()
            .getReference("Kasebo_Stores")
            .child(storeId)
            .child("orders")

        databaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ordersList = mutableListOf<CustomerOrder>()
                for (child in snapshot.children) {
                    val order = child.getValue(CustomerOrder::class.java)
                    if (order != null) ordersList.add(order)
                }
                onOrdersUpdate(ordersList.sortedByDescending { it.timestamp })
            }

            override fun onCancelled(error: DatabaseError) {
                onOrdersUpdate(emptyList())
            }
        })
    }

    // 🔍 الاستماع لطلبات الزبون برقم الهاتف
    fun listenToCustomerSpecificOrders(
        storeId: String,
        customerPhone: String,
        onOrdersUpdate: (List<CustomerOrder>) -> Unit
    ) {
        if (storeId.isBlank()) {
            onOrdersUpdate(emptyList())
            return
        }

        val databaseRef = FirebaseDatabase.getInstance()
            .getReference("Kasebo_Stores")
            .child(storeId)
            .child("orders")

        val cleanPhone = customerPhone.trim()

        databaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ordersList = mutableListOf<CustomerOrder>()
                for (child in snapshot.children) {
                    val order = child.getValue(CustomerOrder::class.java)
                    if (order != null && order.customerPhone.trim() == cleanPhone) {
                        ordersList.add(order)
                    }
                }
                onOrdersUpdate(ordersList.sortedByDescending { it.timestamp })
            }

            override fun onCancelled(error: DatabaseError) {
                onOrdersUpdate(emptyList())
            }
        })
    }

    // 🔄 معالجة الطلب بشكل آمن: حجز المعالجة ذرّياً ثم خصم المخزون داخل Transaction.
    // لا نعيد كتابة قائمة المنتجات/المبيعات كاملة، وبالتالي لا نمسح تغييرات جهاز آخر.
    fun updateOrderStatus(
        storeId: String,
        orderId: String,
        newStatus: String,
        onSuccess: () -> Unit = {},
        onFailure: (String) -> Unit = {}
    ) {
        if (storeId.isBlank() || orderId.isBlank()) {
            onFailure("بيانات الطلب غير صالحة")
            return
        }

        val storeRef = FirebaseDatabase.getInstance()
            .getReference("Kasebo_Stores")
            .child(storeId)
        val orderRef = storeRef.child("orders").child(orderId)
        val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
        if (uid.isNullOrBlank()) {
            onFailure("جلسة المستخدم غير صالحة")
            return
        }

        val claimId = "$uid-${System.currentTimeMillis()}"
        val now = System.currentTimeMillis()
        val claimTimeoutMs = 2 * 60 * 1000L

        // المرحلة الأولى: حجز الطلب مرة واحدة فقط. هذا يمنع جهازين من معالجة نفس الطلب معاً.
        orderRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(currentData: com.google.firebase.database.MutableData): com.google.firebase.database.Transaction.Result {
                if (currentData.value == null) return com.google.firebase.database.Transaction.abort()

                val currentProcessed = currentData.child("isProcessed").value as? Boolean ?: false
                if (currentProcessed) return com.google.firebase.database.Transaction.success(currentData)

                val existingClaim = currentData.child("processingClaimId").value?.toString().orEmpty()
                val existingClaimAt = currentData.child("processingClaimAt").value?.toString()?.toLongOrNull() ?: 0L
                if (existingClaim.isNotBlank() && existingClaim != claimId && now - existingClaimAt < claimTimeoutMs) {
                    return com.google.firebase.database.Transaction.abort()
                }

                currentData.child("processingClaimId").value = claimId
                currentData.child("processingClaimAt").value = now
                currentData.child("processingStatus").value = newStatus
                return com.google.firebase.database.Transaction.success(currentData)
            }

            override fun onComplete(
                error: com.google.firebase.database.DatabaseError?,
                committed: Boolean,
                currentData: com.google.firebase.database.DataSnapshot?
            ) {
                if (error != null) {
                    onFailure(error.message)
                    return
                }
                if (!committed || currentData == null) {
                    onFailure("الطلب قيد المعالجة من جهاز آخر أو تعذر حجزه")
                    return
                }

                val processed = currentData.child("isProcessed").value as? Boolean ?: false
                if (processed) {
                    // العملية تمت سابقاً؛ نكتفي بتحديث الحالة المطلوبة.
                    orderRef.child("status").setValue(newStatus)
                        .addOnSuccessListener { onSuccess() }
                        .addOnFailureListener { e -> onFailure(e.message ?: "تعذر تحديث حالة الطلب") }
                    return
                }

                val orderSnapshot = currentData
                val shouldProcess = newStatus == "Processing" ||
                    newStatus == "Delivered" ||
                    newStatus == "Completed"

                if (!shouldProcess) {
                    val updates = hashMapOf<String, Any>("status" to newStatus)
                    orderRef.updateChildren(updates)
                        .addOnSuccessListener { onSuccess() }
                        .addOnFailureListener { e ->
                            // تحرير الحجز إذا فشل التحديث البسيط.
                            orderRef.updateChildren(
                                mapOf("processingClaimId" to null, "processingClaimAt" to null, "processingStatus" to null)
                            )
                            onFailure(e.message ?: "تعذر تحديث حالة الطلب")
                        }
                    return
                }

                val items = orderSnapshot.child("items").children.mapNotNull { item ->
                    val productId = item.child("productId").value?.toString().orEmpty()
                    val quantity = item.child("quantity").value?.toString()?.toDoubleOrNull() ?: 0.0
                    val price = item.child("price").value?.toString()?.toDoubleOrNull() ?: 0.0
                    if (productId.isBlank() || quantity <= 0.0) null
                    else Triple(productId, quantity, price)
                }
                if (items.isEmpty()) {
                    orderRef.updateChildren(mapOf("processingClaimId" to null, "processingClaimAt" to null, "processingStatus" to null))
                    onFailure("الطلب لا يحتوي على منتجات صالحة")
                    return
                }

                val productsRef = storeRef.child("products")
                productsRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                    override fun doTransaction(data: com.google.firebase.database.MutableData): com.google.firebase.database.Transaction.Result {
                        for ((productId, quantity, _) in items) {
                            val productNode = data.children.firstOrNull {
                                it.child("id").value?.toString() == productId || it.key == productId
                            } ?: return com.google.firebase.database.Transaction.abort()
                            val stock = productNode.child("stockQuantity").value?.toString()?.toDoubleOrNull()
                                ?: productNode.child("qty").value?.toString()?.toDoubleOrNull() ?: 0.0
                            if (quantity > stock) return com.google.firebase.database.Transaction.abort()
                        }

                        for ((productId, quantity, _) in items) {
                            val productNode = data.children.firstOrNull {
                                it.child("id").value?.toString() == productId || it.key == productId
                            } ?: return com.google.firebase.database.Transaction.abort()
                            val stock = productNode.child("stockQuantity").value?.toString()?.toDoubleOrNull()
                                ?: productNode.child("qty").value?.toString()?.toDoubleOrNull() ?: 0.0
                            productNode.child("stockQuantity").value = stock - quantity
                        }
                        return com.google.firebase.database.Transaction.success(data)
                    }

                    override fun onComplete(
                        error: com.google.firebase.database.DatabaseError?,
                        committed: Boolean,
                        productData: com.google.firebase.database.DataSnapshot?
                    ) {
                        if (error != null || !committed || productData == null) {
                            orderRef.updateChildren(mapOf("processingClaimId" to null, "processingClaimAt" to null, "processingStatus" to null))
                            onFailure(error?.message ?: "المخزون غير كافٍ أو تغير على الخادم")
                            return
                        }

                        var addedCash = 0.0
                        var addedProfit = 0.0
                        val finalUpdates = HashMap<String, Any?>()
                        val timestamp = System.currentTimeMillis()

                        for ((productId, quantity, requestedPrice) in items) {
                            val productNode = productData.children.firstOrNull {
                                it.child("id").value?.toString() == productId || it.key == productId
                            } ?: continue
                            val name = productNode.child("name").value?.toString().orEmpty()
                            val purchase = productNode.child("purchasePrice").value?.toString()?.toDoubleOrNull()
                                ?: productNode.child("purchase").value?.toString()?.toDoubleOrNull() ?: 0.0
                            val selling = productNode.child("sellingPrice").value?.toString()?.toDoubleOrNull()
                                ?: productNode.child("sell").value?.toString()?.toDoubleOrNull() ?: requestedPrice
                            val price = if (requestedPrice > 0.0) requestedPrice else selling
                            val revenue = price * quantity
                            val profit = revenue - purchase * quantity
                            addedCash += revenue
                            addedProfit += profit

                            val saleId = "${orderId}_${productId}"
                            finalUpdates["sales/$saleId"] = SaleRecord(
                                saleId = saleId,
                                invoiceId = orderId,
                                productId = productId,
                                staffUid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty(),
                                productName = name,
                                quantity = quantity,
                                revenue = revenue,
                                profit = profit,
                                timestamp = timestamp
                            )
                        }

                        // ServerValue.increment يمنع جهازاً آخر من ضياع تحديثه أثناء حساب الإجمالي.
                        finalUpdates["totalCash"] = com.google.firebase.database.ServerValue.increment(addedCash)
                        finalUpdates["totalProfit"] = com.google.firebase.database.ServerValue.increment(addedProfit)
                        finalUpdates["orders/$orderId/status"] = newStatus
                        finalUpdates["orders/$orderId/isProcessed"] = true
                        finalUpdates["orders/$orderId/processedAt"] = timestamp
                        finalUpdates["orders/$orderId/processedBy"] = uid
                        finalUpdates.remove("orders/$orderId/processingClaimId")
                        finalUpdates.remove("orders/$orderId/processingClaimAt")
                        finalUpdates.remove("orders/$orderId/processingStatus")

                        storeRef.updateChildren(finalUpdates)
                            .addOnSuccessListener { onSuccess() }
                            .addOnFailureListener { e ->
                                onFailure(e.message ?: "تم خصم المخزون لكن تعذر إكمال تسجيل البيع")
                            }
                    }
                })
            }
        })
    }

}
