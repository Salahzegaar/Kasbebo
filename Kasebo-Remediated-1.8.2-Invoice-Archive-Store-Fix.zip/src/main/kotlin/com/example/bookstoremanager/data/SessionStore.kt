package com.example.bookstoremanager.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

/**
 * Central session boundary.
 * Authentication state is global (Firebase owns the actual credential/session).
 * Business preferences are namespaced by store to prevent cross-account leakage.
 */
object SessionStore {
    private const val PREFS = "KaseboSession"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun storeId(context: Context): String =
        prefs(context).getString("store_secret_id", "").orEmpty().trim()

    fun uid(context: Context): String =
        prefs(context).getString("logged_in_user", "").orEmpty().trim()

    fun role(context: Context): String =
        prefs(context).getString("user_role", "").orEmpty()

    fun isOwner(context: Context): Boolean = role(context).equals("Admin", ignoreCase = true)

    fun isCashier(context: Context): Boolean = role(context).equals("Cashier", ignoreCase = true)

    fun hasRole(context: Context, vararg allowedRoles: String): Boolean {
        val current = role(context)
        return allowedRoles.any { it.equals(current, ignoreCase = true) }
    }

    fun save(context: Context, storeId: String, uid: String, role: String = "Admin") {
        prefs(context).edit()
            .putString("store_secret_id", storeId)
            .putString("logged_in_user", uid)
            .putString("user_role", role)
            .apply()
    }

    fun clear(context: Context) {
        prefs(context).edit()
            .remove("store_secret_id")
            .remove("logged_in_user")
            .remove("active_role")
            .remove("user_role")
            .remove("last_notified_order_time")
            .apply()
    }

    fun currentStorePrefs(context: Context): SharedPreferences {
        val storeId = storeId(context)
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(storeId.toByteArray(Charsets.UTF_8))
        val key = digest.joinToString("") { "%02x".format(it) }.take(24)
        return context.getSharedPreferences("KaseboStore_$key", Context.MODE_PRIVATE)
    }
}
