package com.example.bookstoremanager.data

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Local verifier for offline staff-management actions.
 * It stores salted PBKDF2 verifiers, never recoverable plaintext passwords.
 * Firebase Authentication remains the source of truth for the store owner account.
 */
object LocalCredentialStore {
    private const val PREFS = "StorePrefs"
    private const val HASHES_KEY = "app_user_verifiers"
    private const val LEGACY_KEY = "app_users"
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH = 256
    private const val SALT_LENGTH = 16

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun migrateLegacyPlaintext(context: Context) {
        val p = prefs(context)
        val legacy = p.getString(LEGACY_KEY, null) ?: return
        val current = p.getString(HASHES_KEY, null)
        if (!current.isNullOrBlank()) return
        try {
            val old = JSONObject(legacy)
            val verifiers = JSONObject()
            val keys = old.keys()
            while (keys.hasNext()) {
                val user = keys.next()
                val password = old.optString(user, "")
                if (password.isNotEmpty()) verifiers.put(user, createVerifier(password))
            }
            p.edit().putString(HASHES_KEY, verifiers.toString()).remove(LEGACY_KEY).apply()
        } catch (_: Exception) {
            // Invalid legacy data is discarded rather than copied into the new store.
            p.edit().remove(LEGACY_KEY).apply()
        }
    }

    fun users(context: Context): Set<String> {
        migrateLegacyPlaintext(context)
        return try {
            val obj = JSONObject(prefs(context).getString(HASHES_KEY, "{}") ?: "{}")
            buildSet {
                val keys = obj.keys()
                while (keys.hasNext()) add(keys.next())
            }
        } catch (_: Exception) { emptySet() }
    }

    fun hasUser(context: Context, username: String): Boolean = users(context).contains(username)

    fun verify(context: Context, username: String, password: String): Boolean {
        migrateLegacyPlaintext(context)
        if (username.isBlank() || password.isEmpty()) return false
        return try {
            val obj = JSONObject(prefs(context).getString(HASHES_KEY, "{}") ?: "{}")
            val encoded = obj.optString(username, "")
            if (encoded.isBlank()) false else verifyVerifier(password, encoded)
        } catch (_: Exception) { false }
    }

    fun setPassword(context: Context, username: String, password: String): Boolean {
        if (username.isBlank() || password.length < 6) return false
        migrateLegacyPlaintext(context)
        return try {
            val p = prefs(context)
            val obj = JSONObject(p.getString(HASHES_KEY, "{}") ?: "{}")
            obj.put(username, createVerifier(password))
            p.edit().putString(HASHES_KEY, obj.toString()).apply()
            true
        } catch (_: Exception) { false }
    }

    fun removeUser(context: Context, username: String) {
        migrateLegacyPlaintext(context)
        try {
            val p = prefs(context)
            val obj = JSONObject(p.getString(HASHES_KEY, "{}") ?: "{}")
            obj.remove(username)
            p.edit().putString(HASHES_KEY, obj.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun createVerifier(password: String): String {
        val salt = ByteArray(SALT_LENGTH).also { SecureRandom().nextBytes(it) }
        val hash = derive(password, salt, ITERATIONS, KEY_LENGTH)
        return "$ITERATIONS:${Base64.encodeToString(salt, Base64.NO_WRAP)}:${Base64.encodeToString(hash, Base64.NO_WRAP)}"
    }

    private fun verifyVerifier(password: String, encoded: String): Boolean {
        val parts = encoded.split(":")
        if (parts.size != 3) return false
        val iterations = parts[0].toIntOrNull() ?: return false
        val salt = Base64.decode(parts[1], Base64.NO_WRAP)
        val expected = Base64.decode(parts[2], Base64.NO_WRAP)
        val actual = derive(password, salt, iterations, expected.size * 8)
        return MessageDigest.isEqual(actual, expected)
    }

    private fun derive(password: String, salt: ByteArray, iterations: Int, bits: Int): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, bits)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
}
