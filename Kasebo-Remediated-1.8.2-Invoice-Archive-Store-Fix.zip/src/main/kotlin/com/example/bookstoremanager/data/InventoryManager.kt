package com.example.bookstoremanager.data

import com.example.bookstoremanager.*
import android.content.Context
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import com.google.firebase.auth.FirebaseAuth
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.security.MessageDigest

class InventoryManager(private val context: Context) {
    private var activeStoreId: String = ""
    private var dbHelper = LocalDatabaseHelper(context, "kasebo_guest.db")
    private var jsonFile = File(context.filesDir, "kasebo_guest.json")
    private var storeListener: ValueEventListener? = null
    private var ordersListener: ValueEventListener? = null

    private val productList = mutableListOf<Product>()
    private val salesHistory = mutableListOf<SaleRecord>()
    private val expenseList = mutableListOf<ExpenseRecord>()
    private val customerList = mutableListOf<CustomerAccount>()
    private val shoppingCart = mutableListOf<CartItem>()
    private val incomingOrdersList = mutableListOf<CustomerOrder>()

    private var totalCashCollected = 0.0
    private var totalRealProfit = 0.0
    private val checkoutLock = Any()
    private val syncLock = Any()
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var syncInProgress = false
    private var localChangeGeneration = 0L
    private val syncPrefsName = "offline_sync_state"
    private val offlineSalesKeyPrefix = "pending_offline_sales_"
    private val offlineInvoiceStatesKeyPrefix = "offline_invoice_states_"
    private var offlineSalesSyncInProgress = false
    private var dataChangedCallback: (() -> Unit)? = null

    /** UI invalidation hook: keeps Compose screens in sync with local/Firebase changes. */
    fun setDataChangedListener(listener: (() -> Unit)?) {
        dataChangedCallback = listener
        listener?.invoke()
    }

    private fun notifyDataChanged() {
        try { dataChangedCallback?.invoke() } catch (_: Exception) {}
    }

    private fun parseSpreadsheetDate(value: String): Long? {
        val clean = value.trim()
        if (clean.isBlank()) return 0L
        clean.toDoubleOrNull()?.let { serial ->
            if (serial >= 1.0 && serial <= 2958465.0) {
                return ((serial - 25569.0) * 86400000.0).toLong()
            }
        }
        return try {
            SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(clean)?.time
        } catch (_: Exception) { null }
    }

    init {
        val storeId = getCurrentStoreId()
        if (storeId.isNotBlank() && FirebaseAuth.getInstance().currentUser != null) {
            bindStore(storeId, startListener = false)
        }
    }

    private fun getCurrentStoreId(): String {
        val prefs = SessionStore.currentStorePrefs(context)
        return prefs.getString("store_secret_id", "").orEmpty().trim()
    }

    private fun databaseNameForStore(storeId: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(storeId.toByteArray(Charsets.UTF_8))
        val key = digest.joinToString("") { "%02x".format(it) }.take(24)
        return "kasebo_store_$key.db"
    }

    private fun jsonFileForStore(storeId: String): File {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(storeId.toByteArray(Charsets.UTF_8))
        val key = digest.joinToString("") { "%02x".format(it) }.take(24)
        return File(context.filesDir, "kasebo_store_$key.json")
    }

    private fun syncPrefs() = context.getSharedPreferences(syncPrefsName, Context.MODE_PRIVATE)

    private fun isOfflineDirty(): Boolean =
        syncPrefs().getBoolean("dirty_$activeStoreId", false)

    private fun markOfflineDirty() {
        if (activeStoreId.isNotBlank()) {
            localChangeGeneration++
            syncPrefs().edit().putBoolean("dirty_$activeStoreId", true).apply()
        }
    }

    private fun clearOfflineDirty() {
        if (activeStoreId.isNotBlank()) {
            syncPrefs().edit().putBoolean("dirty_$activeStoreId", false).apply()
        }
    }

    private fun hasNetwork(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } else {
            @Suppress("DEPRECATION")
            cm.activeNetworkInfo?.isConnected == true
        }
    }

    private val connectivityHandler = Handler(Looper.getMainLooper())
    private var connectivitySyncScheduled = false

    private fun triggerSyncAfterConnectivity() {
        if (activeStoreId.isBlank() || !isOfflineDirty()) return
        if (!hasNetwork()) return
        if (connectivitySyncScheduled) return
        connectivitySyncScheduled = true
        connectivityHandler.postDelayed({
            connectivitySyncScheduled = false
            if (activeStoreId.isBlank() || !hasNetwork()) return@postDelayed
            if (pendingOfflineSalesSnapshot().length() > 0) syncPendingOfflineSales()
            else autoSyncToCloud()
        }, 500L)
    }

    private fun registerNetworkSync() {
        if (networkCallback != null) return
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                triggerSyncAfterConnectivity()
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                if (networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                    triggerSyncAfterConnectivity()
                }
            }
        }
        try {
            cm.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build(),
                callback
            )
            networkCallback = callback
            // registerNetworkCallback may not deliver an immediate callback on every
            // Android/CodeAssist runtime. Explicitly test the current connection too.
            triggerSyncAfterConnectivity()
        } catch (_: Exception) {
            networkCallback = null
        }
    }

    private fun unregisterNetworkSync() {
        val callback = networkCallback ?: return
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        try { cm?.unregisterNetworkCallback(callback) } catch (_: Exception) {}
        networkCallback = null
    }

    private fun addPendingDelete(type: String, id: String) {
        if (activeStoreId.isBlank() || id.isBlank()) return
        val prefs = syncPrefs()
        val root = try { JSONObject(prefs.getString(pendingDeletesKey(), "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val array = root.optJSONArray(type) ?: JSONArray()
        var exists = false
        for (i in 0 until array.length()) if (array.optString(i) == id) exists = true
        if (!exists) array.put(id)
        root.put(type, array)
        prefs.edit().putString(pendingDeletesKey(), root.toString()).apply()
    }

    private fun pendingDeletesSnapshot(): JSONObject {
        return try { JSONObject(syncPrefs().getString(pendingDeletesKey(), "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    }

    private fun pendingDeletesKey(): String = "pending_deletes_$activeStoreId"

    private fun pendingOfflineSalesKey(): String = "${offlineSalesKeyPrefix}$activeStoreId"

    private fun offlineInvoiceStatesKey(): String = "${offlineInvoiceStatesKeyPrefix}$activeStoreId"

    private fun offlineInvoiceStatesSnapshot(): JSONObject {
        return try {
            JSONObject(syncPrefs().getString(offlineInvoiceStatesKey(), "{}") ?: "{}")
        } catch (_: Exception) { JSONObject() }
    }

    private fun setOfflineInvoiceState(invoiceId: String, status: String, error: String? = null) {
        if (activeStoreId.isBlank() || invoiceId.isBlank()) return
        val root = offlineInvoiceStatesSnapshot()
        val value = JSONObject().apply {
            put("status", status)
            put("updatedAt", System.currentTimeMillis())
            if (!error.isNullOrBlank()) put("error", error) else remove("error")
        }
        root.put(invoiceId, value)
        syncPrefs().edit().putString(offlineInvoiceStatesKey(), root.toString()).apply()
    }

    fun getPendingOfflineSaleDetails(): List<PendingOfflineSale> {
        val states = offlineInvoiceStatesSnapshot()
        val array = pendingOfflineSalesSnapshot()
        val result = mutableListOf<PendingOfflineSale>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val invoiceId = item.optString("invoiceId", "")
            if (invoiceId.isBlank()) continue
            val state = states.optJSONObject(invoiceId)
            result.add(PendingOfflineSale(
                invoiceId = invoiceId,
                timestamp = item.optLong("timestamp", 0L),
                status = state?.optString("status", item.optString("status", "PENDING")) ?: item.optString("status", "PENDING"),
                error = state?.optString("error", "").orEmpty(),
                itemCount = item.optJSONArray("items")?.length() ?: 0
            ))
        }
        return result.sortedByDescending { it.timestamp }
    }

    fun retryPendingOfflineSale(invoiceId: String): Boolean {
        if (invoiceId.isBlank()) return false
        val exists = pendingOfflineInvoiceIds().contains(invoiceId)
        if (!exists) return false
        setOfflineInvoiceState(invoiceId, "PENDING")
        if (hasNetwork() && !offlineSalesSyncInProgress) syncPendingOfflineSales()
        notifyDataChanged()
        return true
    }

    private fun pendingOfflineSalesSnapshot(): JSONArray {
        return try {
            JSONArray(syncPrefs().getString(pendingOfflineSalesKey(), "[]") ?: "[]")
        } catch (_: Exception) { JSONArray() }
    }

    private fun savePendingOfflineSales(array: JSONArray) {
        syncPrefs().edit().putString(pendingOfflineSalesKey(), array.toString()).apply()
    }

    private fun pendingOfflineInvoiceIds(): Set<String> {
        val result = mutableSetOf<String>()
        val array = pendingOfflineSalesSnapshot()
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.optString("invoiceId")?.takeIf { it.isNotBlank() }?.let { result.add(it) }
        }
        return result
    }

    fun getPendingOfflineSaleCount(): Int = pendingOfflineSalesSnapshot().length()

    fun getPendingOfflineSaleInvoiceIds(): Set<String> = pendingOfflineInvoiceIds()

    fun isInvoicePendingOffline(invoiceId: String): Boolean =
        invoiceId.isNotBlank() && invoiceId in pendingOfflineInvoiceIds()

    fun isNetworkAvailable(): Boolean = hasNetwork()

    /**
     * Foreground recovery hook: when the app returns to the foreground, retry
     * durable offline work without requiring a process restart. This is safe
     * to call repeatedly because the existing sync locks/queue guards prevent
     * duplicate work.
     */
    fun onAppForegrounded() {
        if (activeStoreId.isBlank() || !hasNetwork() || !isOfflineDirty()) return
        if (pendingOfflineSalesSnapshot().length() > 0) {
            if (!offlineSalesSyncInProgress) syncPendingOfflineSales()
        } else {
            autoSyncToCloud()
        }
    }

    private fun removePendingOfflineSale(invoiceId: String) {
        val array = pendingOfflineSalesSnapshot()
        val remaining = JSONArray()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i)
            if (item != null && item.optString("invoiceId") != invoiceId) remaining.put(item)
        }
        savePendingOfflineSales(remaining)
    }

    private fun addPendingOfflineSale(invoiceId: String, timestamp: Long, uid: String, items: List<CartItem>) {
        val array = pendingOfflineSalesSnapshot()
        val root = JSONObject().apply {
            put("invoiceId", invoiceId)
            put("timestamp", timestamp)
            put("uid", uid)
            put("status", "PENDING")
            put("items", JSONArray().also { itemArray ->
                items.forEach { item ->
                    itemArray.put(JSONObject().apply {
                        put("productId", item.product.id)
                        put("productName", item.product.name)
                        put("sellingPrice", item.product.sellingPrice)
                        put("purchasePrice", item.product.purchasePrice)
                        put("quantity", item.quantity)
                        put("unitType", item.product.unitType)
                    })
                }
            })
        }
        // The same invoice is never queued twice.
        for (i in 0 until array.length()) {
            if (array.optJSONObject(i)?.optString("invoiceId") == invoiceId) return
        }
        array.put(root)
        savePendingOfflineSales(array)
        setOfflineInvoiceState(invoiceId, "PENDING")
    }

    private fun pendingItemsFromJson(root: JSONObject): List<CartItem> {
        val result = mutableListOf<CartItem>()
        val items = root.optJSONArray("items") ?: return result
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val id = o.optString("productId", "")
            val qty = o.optDouble("quantity", 0.0)
            if (id.isBlank() || !qty.isFinite() || qty <= 0.0) continue
            val current = productList.find { it.id == id }
            val product = (current ?: Product(
                id = id,
                name = o.optString("productName", ""),
                sellingPrice = o.optDouble("sellingPrice", 0.0),
                purchasePrice = o.optDouble("purchasePrice", 0.0),
                unitType = o.optString("unitType", "قطعة")
            )).copy(
                name = o.optString("productName", current?.name ?: ""),
                sellingPrice = o.optDouble("sellingPrice", current?.sellingPrice ?: 0.0),
                purchasePrice = o.optDouble("purchasePrice", current?.purchasePrice ?: 0.0),
                unitType = o.optString("unitType", current?.unitType ?: "قطعة")
            )
            result.add(CartItem(product, qty))
        }
        return result
    }

    private fun buildInvoiceText(invoiceId: String, timestamp: Long, items: List<CartItem>, pending: Boolean): String {
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(timestamp))
        return buildString {
            append("🧾 فاتورة مبيعات - كاسبو Kasebo\n")
            append("رقم الفاتورة: $invoiceId\n")
            append("التاريخ: $date\n")
            if (pending) append("⚠️ بيع مسجل محلياً - بانتظار المزامنة\n")
            append("----------------\n")
            items.forEach { item ->
                val revenue = item.product.sellingPrice * item.quantity
                append("▪ ${item.product.name}\n  ${item.quantity.formatClean()} ${item.product.unitType} × ${item.product.sellingPrice.formatClean()} = ${revenue.formatClean()} دج\n")
            }
            append("----------------\n💰 المجموع الإجمالي: ${items.sumOf { it.product.sellingPrice * it.quantity }.formatClean()} دج")
            if (!pending) append("\nشكراً لزيارتكم!")
        }
    }

    /**
     * Offline POS: creates a provisional local sale and queues it for the same
     * server-authoritative transaction when connectivity returns. It never
     * writes a provisional sale directly to Firebase.
     */
    fun checkoutCartOffline(onSuccess: (String) -> Unit, onFailure: (String) -> Unit) = synchronized(checkoutLock) {
        if (shoppingCart.isEmpty()) { onFailure("السلة فارغة"); return@synchronized }
        val storeId = activeStoreId.ifBlank { getCurrentStoreId() }
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (storeId.isBlank() || uid.isNullOrBlank()) { onFailure("جلسة المستخدم غير صالحة"); return@synchronized }

        val allowNegativeInventory = SessionStore.currentStorePrefs(context).getBoolean("allow_negative_inventory", false)
        val items = shoppingCart.map { it.copy(product = it.product.copy()) }
        val invalid = items.firstOrNull { item ->
            val local = productList.find { it.id == item.product.id }
            local == null || item.product.id.isBlank() || item.quantity <= 0.0 ||
                (!allowNegativeInventory && (local.stockQuantity < item.quantity))
        }
        if (invalid != null) { onFailure("الكمية المطلوبة غير متوفرة في المخزون المحلي"); return@synchronized }

        val timestamp = System.currentTimeMillis()
        val invoiceId = "INV-OFF-" + UUID.randomUUID().toString().replace("-", "").take(12).uppercase(Locale.US)
        var revenueTotal = 0.0
        var profitTotal = 0.0
        items.forEach { item ->
            val local = productList.first { it.id == item.product.id }
            local.stockQuantity -= item.quantity
            dbHelper.insertOrUpdateProduct(local)
            revenueTotal += item.product.sellingPrice * item.quantity
            profitTotal += (item.product.sellingPrice - item.product.purchasePrice) * item.quantity
            val sale = SaleRecord(
                saleId = "${invoiceId}_${item.product.id}", invoiceId = invoiceId,
                productId = item.product.id, staffUid = uid, productName = item.product.name,
                quantity = item.quantity, revenue = item.product.sellingPrice * item.quantity,
                profit = (item.product.sellingPrice - item.product.purchasePrice) * item.quantity, timestamp = timestamp
            )
            salesHistory.add(0, sale)
            dbHelper.insertSale(sale)
        }
        totalCashCollected += revenueTotal
        totalRealProfit += profitTotal
        addPendingOfflineSale(invoiceId, timestamp, uid, items)
        markOfflineDirty()
        saveCustomerAndFinancials()
        shoppingCart.clear()
        notifyDataChanged()
        onSuccess(buildInvoiceText(invoiceId, timestamp, items, pending = true))
    }

    private fun syncPendingOfflineSales() {
        if (offlineSalesSyncInProgress || !hasNetwork() || activeStoreId.isBlank() || FirebaseAuth.getInstance().currentUser == null) return
        val array = pendingOfflineSalesSnapshot()
        if (array.length() == 0) return
        offlineSalesSyncInProgress = true

        fun process(index: Int) {
            val current = pendingOfflineSalesSnapshot()
            if (index >= current.length()) {
                offlineSalesSyncInProgress = false
                notifyDataChanged()
                if (isOfflineDirty() && hasNetwork()) autoSyncToCloud()
                return
            }
            val root = current.optJSONObject(index)
            if (root == null) { process(index + 1); return }
            val invoiceId = root.optString("invoiceId", "")
            setOfflineInvoiceState(invoiceId, "SYNCING")
            val items = pendingItemsFromJson(root)
            if (invoiceId.isBlank() || items.isEmpty()) {
                if (invoiceId.isNotBlank()) setOfflineInvoiceState(invoiceId, "CONFLICT", "بيانات الفاتورة المحلية غير صالحة")
                offlineSalesSyncInProgress = false
                notifyDataChanged()
                return
            }
            val original = shoppingCart.toList()
            shoppingCart.clear()
            shoppingCart.addAll(items)
            val prefs = SessionStore.currentStorePrefs(context)
            prefs.edit().putString("pending_checkout_invoice_id", invoiceId)
                .putString("pending_checkout_fingerprint", cartSnapshotFingerprint(items)).apply()
            checkoutCartAsync(
                onSuccess = {
                    setOfflineInvoiceState(invoiceId, "COMPLETED")
                    removePendingOfflineSale(invoiceId)
                    process(0)
                },
                onFailure = { message ->
                    shoppingCart.clear()
                    shoppingCart.addAll(original)
                    offlineSalesSyncInProgress = false
                    val conflict = message.contains("تعارض") || message.contains("نقص في المخزون") || message.contains("غير متوفر")
                    setOfflineInvoiceState(invoiceId, if (conflict) "CONFLICT" else "RETRY", message)
                    // Leave the queued sale untouched. A later connectivity event or manual retry can retry it.
                    notifyDataChanged()
                }
            )
        }
        process(0)
    }

    private fun removePendingDelete(type: String, id: String) {
        if (id.isBlank()) return
        val root = pendingDeletesSnapshot()
        val array = root.optJSONArray(type) ?: return
        val remaining = JSONArray()
        for (i in 0 until array.length()) {
            val value = array.optString(i)
            if (value.isNotBlank() && value != id) remaining.put(value)
        }
        if (remaining.length() == 0) root.remove(type) else root.put(type, remaining)
        syncPrefs().edit().putString(pendingDeletesKey(), root.toString()).apply()
    }

    private fun clearPendingDeletes() {
        syncPrefs().edit().remove(pendingDeletesKey()).apply()
    }

    private fun syncPendingDeletes(store: com.google.firebase.database.DatabaseReference, done: (DatabaseError?) -> Unit) {
        val root = pendingDeletesSnapshot()
        val types = listOf("products", "expenses", "customers")
        val pendingByType = types.mapNotNull { type ->
            val array = root.optJSONArray(type) ?: return@mapNotNull null
            val ids = mutableSetOf<String>()
            for (i in 0 until array.length()) {
                array.optString(i).takeIf { it.isNotBlank() }?.let { ids.add(it) }
            }
            if (ids.isEmpty()) null else type to ids
        }
        if (pendingByType.isEmpty()) { done(null); return }

        var remaining = pendingByType.size
        var firstError: DatabaseError? = null
        fun finish(error: DatabaseError?) {
            if (error != null && firstError == null) firstError = error
            remaining--
            if (remaining == 0) done(firstError)
        }
        for ((type, ids) in pendingByType) {
            store.child(type).runTransaction(object : Transaction.Handler {
                override fun doTransaction(data: MutableData): Transaction.Result {
                    val toDelete = data.children.filter { child ->
                        val key = child.key.orEmpty()
                        val id = child.child("id").value?.toString().orEmpty()
                        key in ids || id in ids
                    }.mapNotNull { it.key }
                    for (key in toDelete) data.child(key).value = null
                    return Transaction.success(data)
                }
                override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                    finish(error)
                }
            })
        }
    }

    /**
     * Switch the local cache to one store. Every store gets a different DB/file,
     * preventing one account from inheriting another account's offline cache.
     */
    fun bindStore(storeId: String, startListener: Boolean = true) {
        val clean = storeId.trim()
        if (clean.isBlank()) return
        if (clean == activeStoreId) {
            // The Activity may call bindStore after Compose has already been created.
            // Reload the store-local cache and notify the UI so offline invoices/totals
            // are visible immediately after relaunch without requiring another restart.
            loadFromLocalDatabase()
            registerNetworkSync()
            if (isOfflineDirty() && hasNetwork()) {
                if (pendingOfflineSalesSnapshot().length() > 0) syncPendingOfflineSales()
                else autoSyncToCloud()
            }
            if (startListener) startRealtimeSync()
            notifyDataChanged()
            return
        }

        stopRealtimeSync()
        try { dbHelper.close() } catch (_: Exception) {}

        activeStoreId = clean
        dbHelper = LocalDatabaseHelper(context, databaseNameForStore(clean))
        jsonFile = jsonFileForStore(clean)
        loadFromLocalDatabase()
        registerNetworkSync()
        if (isOfflineDirty() && hasNetwork()) {
            if (pendingOfflineSalesSnapshot().length() > 0) syncPendingOfflineSales()
            else autoSyncToCloud()
        }

        if (startListener) startRealtimeSync()
    }

    fun clearSession() {
        stopRealtimeSync()
        activeStoreId = ""
        productList.clear()
        salesHistory.clear()
        expenseList.clear()
        customerList.clear()
        shoppingCart.clear()
        incomingOrdersList.clear()
        totalCashCollected = 0.0
        totalRealProfit = 0.0
    }

    private fun stopRealtimeSync() {
        unregisterNetworkSync()
        val storeId = activeStoreId
        if (storeId.isNotBlank()) {
            val ref = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(storeId)
            storeListener?.let { ref.removeEventListener(it) }
            val ordersRef = ref.child("orders")
            ordersListener?.let { ordersRef.removeEventListener(it) }
        }
        storeListener = null
        ordersListener = null
    }

    // مزامنة غير مدمرة + دعم العمل دون اتصال: التعديلات المحلية تبقى محفوظة حتى عودة الشبكة.
    fun autoSyncToCloud(onComplete: ((Boolean, String?) -> Unit)? = null) {
        synchronized(syncLock) {
            val storeId = activeStoreId.ifBlank { getCurrentStoreId() }
            val uid = FirebaseAuth.getInstance().currentUser?.uid
            if (storeId.isBlank() || uid.isNullOrBlank()) return

            markOfflineDirty()
            if (!hasNetwork()) {
                onComplete?.invoke(false, "لا يوجد اتصال بالإنترنت. تم حفظ التعديل محلياً وسيتم رفعه تلقائياً عند عودة الاتصال.")
                return
            }
            if (pendingOfflineSalesSnapshot().length() > 0) {
                if (!offlineSalesSyncInProgress) syncPendingOfflineSales()
                onComplete?.invoke(false, "توجد مبيعات محلية بانتظار التأكيد على الخادم.")
                return
            }
            if (syncInProgress) {
                onComplete?.invoke(false, "المزامنة قيد التنفيذ.")
                return
            }
            syncInProgress = true

            try {
                val store = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(storeId)
                val generationAtStart = localChangeGeneration
                var remaining = 6
                var firstError: String? = null
                fun done(error: DatabaseError?) {
                    if (error != null && firstError == null) firstError = error.message
                    remaining--
                    if (remaining == 0) {
                        syncInProgress = false
                        val success = firstError == null
                        if (success && localChangeGeneration == generationAtStart) {
                            clearPendingDeletes()
                            clearOfflineDirty()
                        }
                        onComplete?.invoke(success, firstError)
                        if (success && localChangeGeneration != generationAtStart && hasNetwork()) {
                            autoSyncToCloud()
                        }
                    }
                }
                mergeProductsToCloud(store.child("products"), ::done)
                mergeSalesToCloud(store.child("sales"), ::done)
                mergeExpensesToCloud(store.child("expenses"), ::done)
                mergeCustomersToCloud(store.child("customers"), ::done)
                syncPendingDeletes(store, ::done)
                store.updateChildren(
                    hashMapOf<String, Any>(
                        "totalCash" to totalCashCollected,
                        "totalProfit" to totalRealProfit
                    )
                ).addOnSuccessListener { done(null) }
                    .addOnFailureListener { done(DatabaseError.fromException(it)) }
            } catch (e: Exception) {
                syncInProgress = false
                onComplete?.invoke(false, e.message ?: "تعذر مزامنة البيانات")
            }
        }
    }

    private fun mergeProductsToCloud(ref: com.google.firebase.database.DatabaseReference, done: (DatabaseError?) -> Unit) {
        val local = productList.toList()
        if (local.isEmpty()) { done(null); return }
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                for (product in local) {
                    if (product.id.isBlank()) continue
                    val existing = data.children.firstOrNull {
                        it.child("id").value?.toString() == product.id || it.key == product.id
                    }
                    val target = existing ?: data.child(product.id)
                    target.value = product
                }
                return Transaction.success(data)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) android.util.Log.e("InventoryManager", error.message)
                done(error)
            }
        })
    }

    private fun mergeSalesToCloud(ref: com.google.firebase.database.DatabaseReference, done: (DatabaseError?) -> Unit) {
        val pendingInvoices = pendingOfflineInvoiceIds()
        val local = salesHistory.filter { it.invoiceId.isBlank() || it.invoiceId !in pendingInvoices }.toList()
        if (local.isEmpty()) { done(null); return }
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                for (sale in local) {
                    val saleId = sale.saleId.ifBlank { "LEGACY-${sale.timestamp}-${sale.productId}" }
                    val existing = data.children.firstOrNull {
                        it.child("saleId").value?.toString() == saleId || it.key == saleId
                    }
                    val target = existing ?: data.child(saleId)
                    target.value = sale.copy(saleId = saleId)
                }
                return Transaction.success(data)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) android.util.Log.e("InventoryManager", error.message)
                done(error)
            }
        })
    }

    private fun mergeExpensesToCloud(ref: com.google.firebase.database.DatabaseReference, done: (DatabaseError?) -> Unit) {
        val local = expenseList.toList()
        if (local.isEmpty()) { done(null); return }
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                for (expense in local) {
                    if (expense.id.isBlank()) continue
                    val target = data.children.firstOrNull { it.child("id").value?.toString() == expense.id }
                        ?: data.child(expense.id)
                    target.value = expense
                }
                return Transaction.success(data)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) android.util.Log.e("InventoryManager", error.message)
                done(error)
            }
        })
    }

    private fun mergeCustomersToCloud(ref: com.google.firebase.database.DatabaseReference, done: (DatabaseError?) -> Unit) {
        val local = customerList.toList()
        if (local.isEmpty()) { done(null); return }
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                for (customer in local) {
                    if (customer.id.isBlank()) continue
                    val target = data.children.firstOrNull { it.child("id").value?.toString() == customer.id }
                        ?: data.child(customer.id)
                    target.value = customer
                }
                return Transaction.success(data)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) android.util.Log.e("InventoryManager", error.message)
                done(error)
            }
        })
    }

    fun startRealtimeSync(onUpdate: () -> Unit = {}) {
        val storeId = activeStoreId.ifBlank { getCurrentStoreId() }
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (storeId.isBlank() || uid.isNullOrBlank()) return
        if (storeListener != null) return

        val storeRef = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(storeId)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Ignore callbacks from a previous account/store after logout/switch.
                if (activeStoreId != storeId || FirebaseAuth.getInstance().currentUser?.uid != uid) return
                if (!snapshot.exists()) return
                // لا تستبدل الكاش المحلي بتحديث بعيد بينما توجد تعديلات غير مرفوعة.
                if (isOfflineDirty()) {
                    if (hasNetwork()) autoSyncToCloud()
                    return
                }

                try {
                    totalCashCollected = snapshot.child("totalCash").value?.toString()?.toDoubleOrNull() ?: 0.0
                    totalRealProfit = snapshot.child("totalProfit").value?.toString()?.toDoubleOrNull() ?: 0.0

                    productList.clear()
                    val products = mutableListOf<Product>()
                    for (pSnap in snapshot.child("products").children) {
                        val p = parseProductSnapshot(pSnap)
                        if (p != null) products.add(p)
                    }
                    productList.addAll(products)

                    salesHistory.clear()
                    for (sSnap in snapshot.child("sales").children) {
                        val sale = parseSaleSnapshot(sSnap)
                        if (sale != null) salesHistory.add(sale)
                    }

                    expenseList.clear()
                    for (eSnap in snapshot.child("expenses").children) {
                        val expense = parseExpenseSnapshot(eSnap)
                        if (expense != null) expenseList.add(expense)
                    }

                    customerList.clear()
                    for (cSnap in snapshot.child("customers").children) {
                        val id = cSnap.child("id").value?.toString() ?: cSnap.key ?: ""
                        val name = cSnap.child("name").value?.toString() ?: ""
                        val last = cSnap.child("lastName").value?.toString()
                            ?: cSnap.child("last").value?.toString() ?: ""
                        val phone = cSnap.child("phone").value?.toString() ?: ""
                        val social = cSnap.child("socialMedia").value?.toString()
                            ?: cSnap.child("social").value?.toString() ?: ""
                        val cust = CustomerAccount(id, name, last, phone, social)
                        for (rSnap in cSnap.child("records").children) {
                            val rId = rSnap.child("id").value?.toString() ?: rSnap.key ?: ""
                            val title = rSnap.child("title").value?.toString() ?: ""
                            val amount = rSnap.child("amount").value?.toString()?.toDoubleOrNull() ?: 0.0
                            val isRec = rSnap.child("receivable").value as? Boolean
                                ?: (rSnap.child("isRec").value as? Boolean ?: true)
                            cust.records.add(DebtRecord(rId, title, amount, isRec))
                        }
                        customerList.add(cust)
                    }

                    dbHelper.replaceProducts(products)
                    dbHelper.replaceTransactions(salesHistory, expenseList)
                    saveCustomerAndFinancials()
                    notifyDataChanged()
                    onUpdate()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Firebase rules/authorization failures must not expose stale data.
                if (error.code == DatabaseError.PERMISSION_DENIED) {
                    clearSession()
                }
            }
        }

        storeListener = listener
        storeRef.addValueEventListener(listener)
    }

    private fun parseProductSnapshot(pChild: DataSnapshot): Product? {
        val id = pChild.child("id").value?.toString() ?: pChild.key ?: ""
        val name = pChild.child("name").value?.toString() ?: ""
        if (name.isBlank()) return null
        return Product(
            id = id,
            name = name,
            barcode = pChild.child("barcode").value?.toString() ?: "",
            purchasePrice = pChild.child("purchasePrice").value?.toString()?.toDoubleOrNull() ?: 0.0,
            sellingPrice = pChild.child("sellingPrice").value?.toString()?.toDoubleOrNull() ?: 0.0,
            stockQuantity = pChild.child("stockQuantity").value?.toString()?.toDoubleOrNull() ?: 0.0,
            category = pChild.child("category").value?.toString() ?: "عام",
            unitType = pChild.child("unitType").value?.toString() ?: "قطعة",
            imageUrl = pChild.child("imageUrl").value?.toString() ?: "",
            wholesalePrice = pChild.child("wholesalePrice").value?.toString()?.toDoubleOrNull() ?: 0.0,
            minStockAlert = pChild.child("minStockAlert").value?.toString()?.toDoubleOrNull() ?: 5.0,
            expiryDate = pChild.child("expiryDate").value?.toString()?.toLongOrNull() ?: 0L
        )
    }

    private fun parseSaleSnapshot(sSnap: DataSnapshot): SaleRecord? {
        val name = sSnap.child("productName").value?.toString() ?: return null
        return SaleRecord(
            saleId = sSnap.child("saleId").value?.toString() ?: sSnap.key ?: "",
            invoiceId = sSnap.child("invoiceId").value?.toString() ?: "",
            productId = sSnap.child("productId").value?.toString() ?: "",
            staffUid = sSnap.child("staffUid").value?.toString() ?: "",
            productName = name,
            quantity = sSnap.child("quantity").value?.toString()?.toDoubleOrNull() ?: 0.0,
            revenue = sSnap.child("revenue").value?.toString()?.toDoubleOrNull() ?: 0.0,
            profit = sSnap.child("profit").value?.toString()?.toDoubleOrNull() ?: 0.0,
            timestamp = sSnap.child("timestamp").value?.toString()?.toLongOrNull() ?: 0L
        )
    }

    private fun parseExpenseSnapshot(eSnap: DataSnapshot): ExpenseRecord? {
        val id = eSnap.child("id").value?.toString() ?: eSnap.key ?: return null
        return ExpenseRecord(
            id = id,
            title = eSnap.child("title").value?.toString() ?: "",
            amount = eSnap.child("amount").value?.toString()?.toDoubleOrNull() ?: 0.0,
            timestamp = eSnap.child("timestamp").value?.toString()?.toLongOrNull() ?: 0L
        )
    }

    private fun loadFromLocalDatabase() {
        try {
            productList.clear()
            productList.addAll(dbHelper.getAllProducts())
            salesHistory.clear()
            salesHistory.addAll(dbHelper.getAllSales())
            expenseList.clear()
            expenseList.addAll(dbHelper.getAllExpenses())
            loadCustomerAndFinancials()
            if (productList.isEmpty() && jsonFile.exists()) {
                importFromJson(jsonFile.readText())
            }
            // If the JSON totals were not persisted by an older/offline path, derive
            // them from the durable local sales ledger instead of showing zero.
            if (salesHistory.isNotEmpty() && totalCashCollected == 0.0) {
                totalCashCollected = salesHistory.sumOf { it.revenue }
            }
            if (salesHistory.isNotEmpty() && totalRealProfit == 0.0) {
                totalRealProfit = salesHistory.sumOf { it.profit }
            }
            notifyDataChanged()
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun loadCustomerAndFinancials() {
        try {
            if (!jsonFile.exists()) return
            val jsonStr = jsonFile.readText()
            if (jsonStr.isBlank()) return
            val root = JSONObject(jsonStr)

            totalCashCollected = root.optDouble("totalCash", 0.0)
            totalRealProfit = root.optDouble("totalProfit", 0.0)

            customerList.clear()
            val cArr = root.optJSONArray("customers")
            if (cArr != null) {
                for (i in 0 until cArr.length()) {
                    try {
                        val o = cArr.getJSONObject(i)
                        val cust = CustomerAccount(
                            o.optString("id", ""), o.optString("name", ""), o.optString("last", ""), o.optString("phone", ""), o.optString("social", "")
                        )
                        val rArr = o.optJSONArray("records")
                        if (rArr != null) {
                            for (j in 0 until rArr.length()) {
                                try {
                                    val ro = rArr.getJSONObject(j)
                                    cust.records.add(DebtRecord(ro.optString("id", ""), ro.optString("title", ""), ro.optString("amount", "0.0").toDoubleOrNull() ?: 0.0, ro.optBoolean("isRec", true)))
                                } catch (e: Exception) { e.printStackTrace() }
                            }
                        }
                        customerList.add(cust)
                    } catch (e: Exception) { e.printStackTrace() }
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun saveCustomerAndFinancials() {
        try {
            val root = JSONObject()
            root.put("totalCash", totalCashCollected)
            root.put("totalProfit", totalRealProfit)
            val cArr = JSONArray()
            for (c in customerList) {
                val o = JSONObject().apply { put("id", c.id); put("name", c.name); put("last", c.lastName); put("phone", c.phone); put("social", c.socialMedia) }
                val rArr = JSONArray()
                for (r in c.records) {
                    rArr.put(JSONObject().apply { put("id", r.id); put("title", r.title); put("amount", r.amount); put("isRec", r.isReceivable) })
                }
                o.put("records", rArr)
                cArr.put(o)
            }
            root.put("customers", cArr)
            jsonFile.writeText(root.toString())
        } catch (e: Exception) { e.printStackTrace() }
    }

    fun addProduct(product: Product) {
        if (product.validationError() != null) return
        val existingIndex = productList.indexOfFirst { it.id == product.id || (it.name.trim().lowercase() == product.name.trim().lowercase() && product.name.isNotBlank()) }
        val productToSave = if (existingIndex >= 0) {
            val originalId = productList[existingIndex].id
            val updated = product.copy(id = originalId)
            productList[existingIndex] = updated
            updated
        } else {
            productList.add(product)
            product
        }
        dbHelper.insertOrUpdateProduct(productToSave)
        removePendingDelete("products", productToSave.id)
        autoSyncToCloud()
    }

    fun addProducts(newProducts: List<Product>) {
        val validProducts = newProducts.filter { it.validationError() == null }
        if (validProducts.isNotEmpty()) {
            for (p in validProducts) {
                val existingIndex = productList.indexOfFirst { it.id == p.id || (it.name.trim().lowercase() == p.name.trim().lowercase() && p.name.isNotBlank()) }
                if (existingIndex >= 0) {
                    productList[existingIndex] = p.copy(id = productList[existingIndex].id)
                } else {
                    productList.add(p)
                }
            }
            dbHelper.insertBatchProducts(validProducts)
            validProducts.forEach { removePendingDelete("products", it.id) }
            autoSyncToCloud()
        }
    }

    fun updateProduct(product: Product) {
        if (product.validationError() != null) return
        productList.removeAll { it.name.trim().lowercase() == product.name.trim().lowercase() && it.id != product.id }
        var index = productList.indexOfFirst { it.id == product.id }
        if (index < 0) index = productList.indexOfFirst { it.name.trim().lowercase() == product.name.trim().lowercase() }
        val productToSave = if (index >= 0) {
            val originalId = productList[index].id
            val updated = product.copy(id = originalId)
            productList[index] = updated
            updated
        } else {
            productList.add(product)
            product
        }
        dbHelper.insertOrUpdateProduct(productToSave)
        removePendingDelete("products", productToSave.id)
        autoSyncToCloud()
    }

    fun removeProduct(id: String): Boolean {
        val removed = productList.removeIf { it.id == id }
        if (removed) {
            dbHelper.deleteProduct(id)
            addPendingDelete("products", id)
            autoSyncToCloud()
        }
        return removed
    }

    // ==========================================
    // 🔍 قراءة عناوين الأعمدة من ملف CSV
    // ==========================================
    fun getCsvHeaders(context: Context, uri: Uri): List<String> {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val reader = BufferedReader(InputStreamReader(inputStream!!))
            val firstLine = reader.readLine() ?: ""
            inputStream.close()

            val separator = if (firstLine.contains(";")) ";" else ","
            if (firstLine.isBlank()) emptyList() else firstLine.split(separator).map { it.trim() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ==========================================
    // 📥 استيراد المنتجات المطور (بدعم ربط الأعمدة الديناميكي)
    // ==========================================
    fun importProductsFromCsvMapped(
        context: Context,
        uri: Uri,
        nameIdx: Int,
        barcodeIdx: Int,
        purchaseIdx: Int,
        sellIdx: Int,
        qtyIdx: Int,
        catIdx: Int,
        hasHeaderRow: Boolean,
        expiryIdx: Int = -1,
        onSuccess: (Int) -> Unit,
        onFailure: (String) -> Unit
    ) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
            if (inputStream == null) {
                onFailure("لم نتمكن من قراءة الملف!")
                return
            }

            val reader = BufferedReader(InputStreamReader(inputStream))
            val lines = reader.readLines()

            if (lines.isEmpty() || (hasHeaderRow && lines.size <= 1)) {
                onFailure("الملف فارغ أو لا يحتوي على بيانات منتجات!")
                return
            }

            val productsToSaveLocally = mutableListOf<Product>()
            val startIndex = if (hasHeaderRow) 1 else 0
            var addedOrUpdatedCount = 0

            for (i in startIndex until lines.size) {
                val line = lines[i]
                if (line.isBlank()) continue

                val separator = if (line.contains(";")) ";" else ","
                val columns = line.split(separator)

                val name = if (nameIdx in columns.indices && nameIdx != -1) columns[nameIdx].trim() else ""
                val barcode = if (barcodeIdx in columns.indices && barcodeIdx != -1) columns[barcodeIdx].trim() else ""

                val purchasePriceStr = if (purchaseIdx in columns.indices && purchaseIdx != -1) columns[purchaseIdx].trim() else "0"
                val sellingPriceStr = if (sellIdx in columns.indices && sellIdx != -1) columns[sellIdx].trim() else "0"
                val qtyStr = if (qtyIdx in columns.indices && qtyIdx != -1) columns[qtyIdx].trim() else "0"
                val expiryStr = if (expiryIdx in columns.indices && expiryIdx != -1) columns[expiryIdx].trim() else ""

                val purchasePrice = purchasePriceStr.replace(",", ".").toDoubleOrNull()
                val sellingPrice = sellingPriceStr.replace(",", ".").toDoubleOrNull()
                val stock = qtyStr.replace(",", ".").toDoubleOrNull()
                val expiryDate = parseSpreadsheetDate(expiryStr)
                if (purchasePrice == null || sellingPrice == null || stock == null || expiryDate == null || purchasePrice < 0.0 || sellingPrice <= 0.0 || stock < 0.0) {
                    onFailure("بيانات رقمية غير صالحة في السطر ${i + 1}")
                    return
                }
                val purchaseValue = purchasePrice
                val sellingValue = sellingPrice
                val stockValue = stock
                val expiryValue = expiryDate

                val category = if (catIdx in columns.indices && catIdx != -1) columns[catIdx].trim() else "عام"

                if (name.isNotBlank()) {
                    val existingIndex = productList.indexOfFirst {
                        (it.barcode.isNotBlank() && it.barcode == barcode) ||
                        (it.name.trim().equals(name, ignoreCase = true))
                    }

                    if (existingIndex >= 0) {
                        val existingProduct = productList[existingIndex]
                        val updatedProduct = existingProduct.copy(
                            purchasePrice = if (purchaseIdx != -1) purchaseValue else existingProduct.purchasePrice,
                            sellingPrice = if (sellIdx != -1) sellingValue else existingProduct.sellingPrice,
                            stockQuantity = existingProduct.stockQuantity + stockValue,
                            category = if (category.isNotBlank() && category != "عام") category else existingProduct.category,
                            barcode = barcode.ifBlank { existingProduct.barcode },
                            expiryDate = if (expiryValue > 0L) expiryValue else existingProduct.expiryDate
                        )
                        productList[existingIndex] = updatedProduct
                        productsToSaveLocally.add(updatedProduct)
                    } else {
                        val newProduct = Product(
                            id = UUID.randomUUID().toString(),
                            name = name,
                            barcode = barcode,
                            purchasePrice = purchaseValue,
                            sellingPrice = sellingValue,
                            stockQuantity = stockValue,
                            category = if (category.isBlank()) "عام" else category,
                            expiryDate = expiryValue
                        )
                        productList.add(newProduct)
                        productsToSaveLocally.add(newProduct)
                    }
                    addedOrUpdatedCount++
                }
            }

            if (productsToSaveLocally.isNotEmpty()) {
                dbHelper.insertBatchProducts(productsToSaveLocally)
                autoSyncToCloud()
                onSuccess(addedOrUpdatedCount)
            } else {
                onFailure("لم يتم العثور على بيانات صالحة! تأكد من ربط عمود 'اسم المنتج' بشكل صحيح.")
            }

        } catch (e: Exception) {
            e.printStackTrace()
            onFailure("حدث خطأ: تأكد أن الملف بصيغة CSV ومغلق في التطبيقات الأخرى.")
        }
    }

    fun addExpense(expense: ExpenseRecord) { expenseList.add(0, expense); dbHelper.insertExpense(expense); removePendingDelete("expenses", expense.id); autoSyncToCloud() }
    fun removeExpense(id: String): Boolean {
        val removed = expenseList.removeIf { it.id == id }
        if (removed) {
            dbHelper.deleteExpense(id)
            addPendingDelete("expenses", id)
            autoSyncToCloud()
        }
        return removed
    }

    fun addCustomer(customer: CustomerAccount) { customerList.add(0, customer); saveCustomerAndFinancials(); removePendingDelete("customers", customer.id); autoSyncToCloud() }
    fun removeCustomer(id: String): Boolean {
        val removed = customerList.removeIf { it.id == id }
        if (removed) {
            saveCustomerAndFinancials()
            addPendingDelete("customers", id)
            autoSyncToCloud()
        }
        return removed
    }
    fun addDebtRecordToCustomer(customerId: String, record: DebtRecord): Boolean { val added = customerList.find { it.id == customerId }?.records?.add(0, record) != null; if (added) { saveCustomerAndFinancials(); autoSyncToCloud() }; return added }
    fun removeDebtRecordFromCustomer(customerId: String, recordId: String): Boolean { val removed = customerList.find { it.id == customerId }?.records?.removeIf { it.id == recordId } ?: false; if (removed) { saveCustomerAndFinancials(); autoSyncToCloud() }; return removed }

    fun getShoppingCart(): MutableList<CartItem> = shoppingCart

    fun addToCart(product: Product, quantity: Double): Boolean {
        if (product.stockQuantity < quantity) return false
        val existing = shoppingCart.find { it.product.id == product.id }
        if (existing != null) {
            if (existing.quantity + quantity > product.stockQuantity) return false
            existing.quantity += quantity
        } else {
            shoppingCart.add(CartItem(product, quantity))
        }
        return true
    }

    fun scanAndAddToCart(scannedCode: String, onResult: (Boolean, String) -> Unit) {
        val code = scannedCode.trim()
        val product = productList.find { it.barcode.trim() == code || it.id.trim() == code || it.name.trim().equals(code, ignoreCase = true) }
        if (product != null) {
            val added = addToCart(product, 1.0)
            if (added) onResult(true, "تمت إضافة: ${product.name}") else onResult(false, "نفذت الكمية في المخزون (${product.name})")
        } else {
            onResult(false, "المنتج غير مسجل في المخزون ($code)")
        }
    }

    fun removeFromCart(productId: String) { shoppingCart.removeIf { it.product.id == productId } }
    fun getCartTotal(): Double = shoppingCart.sumOf { it.getTotalPrice() }

    private fun cartSnapshotFingerprint(items: List<CartItem>): String {
        val canonical = items.joinToString("|") {
            "${it.product.id.trim()}=${it.quantity}=${it.product.sellingPrice}=${it.product.purchasePrice}"
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    /**
     * Checkout with a stable invoice ID and a Firebase Realtime Database transaction.
     * The server transaction is the authority for stock, sale creation and totals.
     * Repeated execution of the same invoice is a no-op through checkoutOperations/{invoiceId}.
     */
    fun checkoutCartAsync(onSuccess: (String) -> Unit, onFailure: (String) -> Unit) = synchronized(checkoutLock) {
        if (shoppingCart.isEmpty()) {
            onFailure("السلة فارغة")
            return@synchronized
        }

        val storeId = activeStoreId.ifBlank { getCurrentStoreId() }
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (storeId.isBlank() || uid.isNullOrBlank()) {
            onFailure("جلسة المستخدم غير صالحة")
            return@synchronized
        }
        if (!hasNetwork()) {
            checkoutCartOffline(onSuccess, onFailure)
            return@synchronized
        }

        val allowNegativeInventory = SessionStore.currentStorePrefs(context)
            .getBoolean("allow_negative_inventory", false)
        val transactionTimestamp = System.currentTimeMillis()
        val prefs = SessionStore.currentStorePrefs(context)
        val fingerprint = cartSnapshotFingerprint(shoppingCart)
        val savedInvoice = prefs.getString("pending_checkout_invoice_id", "").orEmpty()
        val savedFingerprint = prefs.getString("pending_checkout_fingerprint", "").orEmpty()
        val invoiceId = if (savedInvoice.isNotBlank() && savedFingerprint == fingerprint) {
            savedInvoice
        } else {
            "INV-" + UUID.randomUUID().toString().replace("-", "").take(12).uppercase(Locale.US)
        }
        val attemptId = UUID.randomUUID().toString()
        prefs.edit().putString("pending_checkout_invoice_id", invoiceId).putString("pending_checkout_fingerprint", fingerprint).apply()
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(transactionTimestamp))
        val cartSnapshot = shoppingCart.map { it.copy(product = it.product.copy()) }

        val invalidItem = cartSnapshot.firstOrNull { item ->
            val product = productList.find { it.id == item.product.id }
            product == null || item.product.id.isBlank() || item.quantity <= 0.0 ||
                (!allowNegativeInventory && product.stockQuantity < item.quantity)
        }
        if (invalidItem != null) {
            prefs.edit().remove("pending_checkout_invoice_id").remove("pending_checkout_fingerprint").apply()
            onFailure("الكمية المطلوبة غير متوفرة أو المنتج غير صالح")
            return@synchronized
        }

        val database = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(storeId)
        database.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                // Idempotency guard: the same invoice can never be applied twice.
                if (currentData.child("checkoutOperations").child(invoiceId).value != null) {
                    return Transaction.success(currentData)
                }

                var totalRevenueDelta = 0.0
                var totalProfitDelta = 0.0
                val saleValues = mutableListOf<Map<String, Any>>()

                for (item in cartSnapshot) {
                    // Products in older stores were stored as an array (numeric Firebase keys).
                    // Resolve by immutable product.id so the transaction works for both legacy and new data.
                    val productData = currentData.child("products").children
                        .firstOrNull { it.child("id").value?.toString() == item.product.id }
                        ?: return Transaction.abort()

                    val stock = productData.child("stockQuantity").value?.toString()?.toDoubleOrNull() ?: return Transaction.abort()
                    val sellingPrice = productData.child("sellingPrice").value?.toString()?.toDoubleOrNull() ?: return Transaction.abort()
                    val purchasePrice = productData.child("purchasePrice").value?.toString()?.toDoubleOrNull() ?: 0.0
                    val qty = item.quantity
                    if (!qty.isFinite() || qty <= 0.0 || (!allowNegativeInventory && stock < qty)) {
                        return Transaction.abort()
                    }

                    val newStock = stock - qty
                    productData.child("stockQuantity").value = newStock
                    val revenue = sellingPrice * qty
                    val profit = revenue - (purchasePrice * qty)
                    totalRevenueDelta += revenue
                    totalProfitDelta += profit

                    val saleId = "${invoiceId}_${item.product.id}"
                    saleValues += mapOf(
                        "saleId" to saleId,
                        "invoiceId" to invoiceId,
                        "productId" to item.product.id,
                        "staffUid" to uid,
                        "productName" to (productData.child("name").value?.toString() ?: item.product.name),
                        "quantity" to qty,
                        "revenue" to revenue,
                        "profit" to profit,
                        "timestamp" to transactionTimestamp
                    )
                }

                val currentCash = currentData.child("totalCash").value?.toString()?.toDoubleOrNull() ?: 0.0
                val currentProfit = currentData.child("totalProfit").value?.toString()?.toDoubleOrNull() ?: 0.0
                currentData.child("totalCash").value = currentCash + totalRevenueDelta
                currentData.child("totalProfit").value = currentProfit + totalProfitDelta

                for (sale in saleValues) {
                    val saleId = sale["saleId"].toString()
                    currentData.child("sales").child(saleId).value = sale
                }

                currentData.child("checkoutOperations").child(invoiceId).value = mapOf(
                    "invoiceId" to invoiceId,
                    "uid" to uid,
                    "attemptId" to attemptId,
                    "timestamp" to transactionTimestamp,
                    "total" to totalRevenueDelta,
                    "status" to "COMMITTED"
                )
                return Transaction.success(currentData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {
                if (error != null) {
                    onFailure("فشل حفظ البيع على الخادم: ${error.message}")
                    return
                }
                if (!committed) {
                    onFailure("تعذر إتمام البيع بسبب تعارض أو نقص في المخزون")
                    return
                }

                val committedByThisAttempt = currentData?.child("checkoutOperations")
                    ?.child(invoiceId)?.child("attemptId")?.value?.toString() == attemptId
                if (!committedByThisAttempt) {
                    // The invoice was already committed by an earlier attempt. Do not apply it locally twice.
                    val duplicateInvoice = buildString {
                        append("🧾 فاتورة مبيعات - كاسبو Kasebo\n")
                        append("رقم الفاتورة: $invoiceId\n")
                        append("----------------\n")
                        cartSnapshot.forEach { item ->
                            val revenue = item.product.sellingPrice * item.quantity
                            append("▪ ${item.product.name}\n  ${item.quantity.formatClean()} ${item.product.unitType} × ${item.product.sellingPrice.formatClean()} = ${revenue.formatClean()} دج\n")
                        }
                        append("----------------\n💰 المجموع الإجمالي: ${cartSnapshot.sumOf { it.product.sellingPrice * it.quantity }.formatClean()} دج")
                    }
                    fetchDataFromFirebase(
                        storeId,
                        onSuccess = {
                            prefs.edit().remove("pending_checkout_invoice_id").remove("pending_checkout_fingerprint").apply()
                            shoppingCart.clear()
                            onSuccess(duplicateInvoice)
                        },
                        onFailure = { message -> onFailure("الفاتورة مسجلة مسبقاً، لكن تعذر تحديث الجهاز: $message") }
                    )
                    return
                }

                val invoice = buildString {
                    append("🧾 فاتورة مبيعات - كاسبو Kasebo\n")
                    append("رقم الفاتورة: $invoiceId\n")
                    append("التاريخ: $date\n")
                    append("----------------\n")
                    cartSnapshot.forEach { item ->
                        val revenue = item.product.sellingPrice * item.quantity
                        append("▪ ${item.product.name}\n  ${item.quantity.formatClean()} ${item.product.unitType} × ${item.product.sellingPrice.formatClean()} = ${revenue.formatClean()} دج\n")
                    }
                    append("----------------\n💰 المجموع الإجمالي: ${cartSnapshot.sumOf { item -> item.product.sellingPrice * item.quantity }.formatClean()} دج\nشكراً لزيارتكم!")
                }

                // Never manually apply stock/totals after the server commit: the realtime listener
                // may already have delivered the authoritative values. Refresh the store snapshot
                // instead, eliminating a local double-decrement race.
                fetchDataFromFirebase(
                    storeId,
                    onSuccess = {
                        shoppingCart.clear()
                        prefs.edit().remove("pending_checkout_invoice_id").remove("pending_checkout_fingerprint").apply()
                        onSuccess(invoice)
                    },
                    onFailure = { message ->
                        // Keep the pending invoice ID so a retry remains idempotent.
                        onFailure("تم حفظ البيع على الخادم، لكن تعذر تحديث الجهاز: $message")
                    }
                )
            }
        })
    }

    fun listenForIncomingCustomerOrders(storeId: String, onOrdersUpdated: (List<CustomerOrder>) -> Unit) {
        val targetStoreId = if (storeId.isNotBlank()) storeId else getCurrentStoreId()
        if (targetStoreId.isBlank()) return

        val ordersRef = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(targetStoreId).child("orders")
        val prefs = SessionStore.currentStorePrefs(context)

        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        ordersListener?.let { ordersRef.removeEventListener(it) }
        val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (activeStoreId != targetStoreId || FirebaseAuth.getInstance().currentUser?.uid != uid) return
                    incomingOrdersList.clear()
                    val lastNotifiedTime = prefs.getLong("last_notified_order_time", System.currentTimeMillis() - 10000)
                    var newestOrderTime = lastNotifiedTime

                    for (child in snapshot.children) {
                        val order = child.getValue(CustomerOrder::class.java)
                        if (order != null) {
                            incomingOrdersList.add(order)
                            if ((order.status == "جديدة" || order.status == "New") && order.timestamp > lastNotifiedTime) {
                                NotificationHelper.showNotification(context, "🛍️ طلب زبون جديد!", "وصلك طلب بقيمة ${order.totalAmount.formatClean()} دج")
                                if (order.timestamp > newestOrderTime) newestOrderTime = order.timestamp
                            }
                        }
                    }
                    if (newestOrderTime > lastNotifiedTime) prefs.edit().putLong("last_notified_order_time", newestOrderTime).apply()
                    incomingOrdersList.sortByDescending { it.timestamp }
                    onOrdersUpdated(incomingOrdersList)
                }
                override fun onCancelled(error: DatabaseError) {
                    if (error.code == DatabaseError.PERMISSION_DENIED) incomingOrdersList.clear()
                }
        }
        ordersListener = listener
        ordersRef.addValueEventListener(listener)
    }

    fun updateOrderStatus(storeId: String, orderId: String, newStatus: String) {
        val targetStoreId = if (storeId.isNotBlank()) storeId else getCurrentStoreId()
        if (targetStoreId.isBlank() || orderId.isBlank()) return
        FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(targetStoreId).child("orders").child(orderId).child("status").setValue(newStatus)
    }

    // ========================================================
    // ⚠️ الأسطر التي سقطت في الكود السابق وأدت إلى الـ 442 خطأ! ⚠️
    // ========================================================
    fun getTotalStoreReceivable(): Double = customerList.sumOf { it.getTotalReceivable() }
    fun getTotalStorePayable(): Double = 0.0

    /**
     * Permanently clears sales/expenses/invoice archive data for the active store.
     * The operation is intentionally online-only: local data is not cleared until
     * Firebase confirms deletion, so a disconnected device can never appear to have
     * permanently deleted cloud records that still exist on the server.
     */
    fun resetDailyDataAsync(onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val storeId = activeStoreId.ifBlank { getCurrentStoreId() }
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (storeId.isBlank() || uid.isNullOrBlank()) {
            onFailure("جلسة المستخدم غير صالحة.")
            return
        }
        if (!hasNetwork()) {
            onFailure("يجب الاتصال بالإنترنت لإجراء التصفير النهائي وحذف البيانات من الخادم.")
            return
        }

        val store = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(storeId)
        val updates = hashMapOf<String, Any?>(
            "sales" to null,
            "expenses" to null,
            "checkoutOperations" to null,
            "archives" to null,
            "totalCash" to 0.0,
            "totalProfit" to 0.0
        )
        store.updateChildren(updates)
            .addOnSuccessListener {
                totalCashCollected = 0.0
                totalRealProfit = 0.0
                salesHistory.clear()
                expenseList.clear()
                shoppingCart.clear()
                dbHelper.resetDaily()
                clearPendingDeletes()
                syncPrefs().edit()
                    .remove(pendingOfflineSalesKey())
                    .remove(offlineInvoiceStatesKey())
                    .putBoolean("dirty_$storeId", false)
                    .apply()
                context.filesDir.listFiles()?.forEach { file ->
                    if (file.name.startsWith("kasebo_reset_archive_")) file.delete()
                }
                saveCustomerAndFinancials()
                onSuccess()
            }
            .addOnFailureListener { e ->
                onFailure("تعذر حذف بيانات المبيعات والفواتير نهائياً: ${e.message ?: "خطأ غير معروف"}")
            }
    }

    fun getLowStockCount(): Int = productList.count { it.stockQuantity <= it.minStockAlert }
    fun getExpiringProducts(now: Long = System.currentTimeMillis()): List<Product> {
        val days = SessionStore.currentStorePrefs(context).getInt("expiry_alert_days", 0)
        if (days <= 0) return emptyList()
        val limit = now + days * 24L * 60L * 60L * 1000L
        return productList.filter { it.expiryDate > 0L && it.expiryDate <= limit }
            .sortedBy { it.expiryDate }
    }

    fun getExpiringProductCount(): Int = getExpiringProducts().size
    fun getProductList(): MutableList<Product> = productList
    fun getSalesHistory(): MutableList<SaleRecord> = salesHistory

    /**
     * Returns the durable sales ledger for the currently bound store.
     * The invoice archive must read from SQLite directly so it never depends
     * on the lifetime of a particular InventoryManager instance or Compose state.
     */
    fun getLocalSalesHistory(): List<SaleRecord> = try {
        dbHelper.getAllSales()
    } catch (_: Exception) {
        salesHistory.toList()
    }
    fun getExpenseList(): MutableList<ExpenseRecord> = expenseList
    fun getCustomerList(): MutableList<CustomerAccount> = customerList
    fun getTotalCashCollected(): Double = totalCashCollected
    fun getTotalRealProfit(): Double = totalRealProfit
    fun setTotalCashCollected(value: Double) {
        totalCashCollected = value
        saveCustomerAndFinancials()
        autoSyncToCloud()
    }
    fun setTotalRealProfit(value: Double) {
        totalRealProfit = value
        saveCustomerAndFinancials()
        autoSyncToCloud()
    }
    fun getTotalExpenses(): Double = expenseList.sumOf { it.amount }
    fun getNetRealProfit(): Double = totalRealProfit - getTotalExpenses()
    fun getTotalInventoryCost(): Double = productList.sumOf { it.purchasePrice * it.stockQuantity }

    fun exportToJson(): String {
        return try {
            val root = JSONObject()
            root.put("totalCash", totalCashCollected)
            root.put("totalProfit", totalRealProfit)
            val pArr = JSONArray()
            for (p in productList) {
                pArr.put(JSONObject().apply {
                        put("id", p.id)
                        put("name", p.name)
                        put("barcode", p.barcode)
                        put("purchasePrice", p.purchasePrice)
                        put("sellingPrice", p.sellingPrice)
                        put("stockQuantity", p.stockQuantity)
                        put("category", p.category)
                        put("unitType", p.unitType)
                        put("imageUrl", p.imageUrl)
                        put("wholesalePrice", p.wholesalePrice)
                        put("minStockAlert", p.minStockAlert)
                        put("expiryDate", p.expiryDate)
                })
            }
            root.put("products", pArr)
            root.toString()
        } catch (e: Exception) { "{}" }
    }

    fun importFromJson(jsonStr: String): Boolean {
        return try {
            val root = JSONObject(jsonStr)
            val pArr = root.optJSONArray("products")
            if (pArr != null) {
                val list = mutableListOf<Product>()
                for (i in 0 until pArr.length()) {
                    val o = pArr.getJSONObject(i)
                    val importedProduct = Product(
                            id = o.optString("id", UUID.randomUUID().toString()),
                            name = o.optString("name", ""),
                            barcode = o.optString("barcode", ""),
                            purchasePrice = o.optDouble("purchasePrice", o.optDouble("purchase", 0.0)),
                            sellingPrice = o.optDouble("sellingPrice", o.optDouble("sell", 0.0)),
                            stockQuantity = o.optDouble("stockQuantity", o.optDouble("qty", 0.0)),
                            category = o.optString("category", "عام"),
                            unitType = o.optString("unitType", "قطعة"),
                            imageUrl = o.optString("imageUrl", ""),
                            wholesalePrice = o.optDouble("wholesalePrice", 0.0),
                            minStockAlert = o.optDouble("minStockAlert", 5.0),
                            expiryDate = o.optLong("expiryDate", 0L)
                        )
                    if (importedProduct.validationError() != null) return false
                    list.add(importedProduct)
                }
                addProducts(list)
            }
            true
        } catch (e: Exception) { false }
    }

    fun syncToFirebase(storeId: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        try {
            if (storeId.isBlank() || FirebaseAuth.getInstance().currentUser?.uid.isNullOrBlank()) {
                onFailure("جلسة المستخدم غير صالحة.")
                return
            }
            bindStore(storeId, startListener = false)
            autoSyncToCloud { success, error ->
                if (!success) {
                    onFailure(error ?: "تعذر مزامنة البيانات")
                    return@autoSyncToCloud
                }
                val database = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(storeId)
                database.updateChildren(
                    hashMapOf<String, Any>(
                        "totalCash" to totalCashCollected,
                        "totalProfit" to totalRealProfit
                    )
                ).addOnSuccessListener { onSuccess() }
                    .addOnFailureListener { e -> onFailure(e.message ?: "تعذر حفظ الإجماليات") }
            }
        } catch (e: Exception) { onFailure(e.message ?: "خطأ غير متوقع") }
    }

    fun fetchDataFromFirebase(storeId: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val cleanStoreId = storeId.trim()
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (cleanStoreId.isBlank() || uid.isNullOrBlank()) {
            onFailure("جلسة المستخدم غير صالحة.")
            return
        }

        // Bind before reading so local data is always scoped to this store.
        bindStore(cleanStoreId, startListener = false)
        val database = FirebaseDatabase.getInstance().getReference("Kasebo_Stores").child(cleanStoreId)
        database.get().addOnSuccessListener { snapshot ->
            if (!snapshot.exists()) {
                clearSession()
                onFailure("لم يتم العثور على متجر بهذا الكود.")
                return@addOnSuccessListener
            }

            val ownerUid = snapshot.child("ownerUid").getValue(String::class.java)
            if (ownerUid != uid) {
                clearSession()
                onFailure("لا تملك صلاحية الوصول إلى هذا المتجر.")
                return@addOnSuccessListener
            }

            try {
                totalCashCollected = snapshot.child("totalCash").value?.toString()?.toDoubleOrNull() ?: 0.0
                totalRealProfit = snapshot.child("totalProfit").value?.toString()?.toDoubleOrNull() ?: 0.0

                val products = mutableListOf<Product>()
                for (pChild in snapshot.child("products").children) {
                    parseProductSnapshot(pChild)?.let(products::add)
                }

                val sales = mutableListOf<SaleRecord>()
                for (sChild in snapshot.child("sales").children) {
                    parseSaleSnapshot(sChild)?.let(sales::add)
                }

                val expenses = mutableListOf<ExpenseRecord>()
                for (eChild in snapshot.child("expenses").children) {
                    parseExpenseSnapshot(eChild)?.let(expenses::add)
                }

                val customers = mutableListOf<CustomerAccount>()
                for (cSnap in snapshot.child("customers").children) {
                    val id = cSnap.child("id").value?.toString() ?: cSnap.key ?: ""
                    val cust = CustomerAccount(
                        id = id,
                        name = cSnap.child("name").value?.toString() ?: "",
                        lastName = cSnap.child("lastName").value?.toString()
                            ?: cSnap.child("last").value?.toString() ?: "",
                        phone = cSnap.child("phone").value?.toString() ?: "",
                        socialMedia = cSnap.child("socialMedia").value?.toString()
                            ?: cSnap.child("social").value?.toString() ?: ""
                    )
                    for (rSnap in cSnap.child("records").children) {
                        cust.records.add(
                            DebtRecord(
                                id = rSnap.child("id").value?.toString() ?: rSnap.key ?: "",
                                title = rSnap.child("title").value?.toString() ?: "",
                                amount = rSnap.child("amount").value?.toString()?.toDoubleOrNull() ?: 0.0,
                                isReceivable = rSnap.child("receivable").value as? Boolean
                                    ?: (rSnap.child("isRec").value as? Boolean ?: true)
                            )
                        )
                    }
                    customers.add(cust)
                }

                productList.clear(); productList.addAll(products)
                salesHistory.clear(); salesHistory.addAll(sales)
                expenseList.clear(); expenseList.addAll(expenses)
                customerList.clear(); customerList.addAll(customers)

                // Replace, never merge, the local cache. This removes stale records.
                dbHelper.replaceProducts(products)
                dbHelper.replaceTransactions(sales, expenses)
                saveCustomerAndFinancials()
                notifyDataChanged()

                onSuccess()
            } catch (e: Exception) {
                clearSession()
                onFailure("خطأ أثناء معالجة بيانات المتجر: ${e.message}")
            }
        }.addOnFailureListener { e ->
            // A temporary network/database read failure must NEVER erase the
            // durable local store cache. The user may have valid offline sales
            // and stock changes that must remain visible after relaunch.
            // Only an explicit authorization failure is allowed to invalidate
            // the active session. Connectivity recovery will retry the read/sync.
            onFailure("تعذر تحديث بيانات المتجر الآن: ${e.message ?: "لا يوجد اتصال"}. تم الاحتفاظ بالبيانات المحلية.")
        }
    }

    private fun readZipEntry(context: Context, uri: Uri, entryName: String): ByteArray? {
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == entryName) {
                        val output = ByteArrayOutputStream()
                        zip.copyTo(output)
                        return output.toByteArray()
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return null
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val result = mutableListOf<String>()
        val parser = XmlPullParserFactory.newInstance().newPullParser().apply {
            setInput(ByteArrayInputStream(bytes), "UTF-8")
        }
        var current = StringBuilder()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "si") current = StringBuilder()
            if (event == XmlPullParser.START_TAG && parser.name == "t") current.append(parser.nextText())
            if (event == XmlPullParser.END_TAG && parser.name == "si") result.add(current.toString())
            event = parser.next()
        }
        return result
    }

    private fun spreadsheetColumnIndex(reference: String): Int {
        val letters = reference.takeWhile { it.isLetter() }.uppercase(Locale.US)
        var result = 0
        for (ch in letters) result = result * 26 + (ch - 'A' + 1)
        return (result - 1).coerceAtLeast(0)
    }

    private fun parseWorksheet(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val parser = XmlPullParserFactory.newInstance().newPullParser().apply {
            setInput(ByteArrayInputStream(bytes), "UTF-8")
        }
        var row = mutableListOf<String>()
        var currentColumn = 0
        var cellType = ""
        var cellReference = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> {
                        cellReference = parser.getAttributeValue(null, "r") ?: ""
                        currentColumn = spreadsheetColumnIndex(cellReference)
                        while (row.size < currentColumn) row.add("")
                        cellType = parser.getAttributeValue(null, "t") ?: ""
                    }
                    "v", "t" -> {
                        val raw = parser.nextText()
                        if (parser.name == "t" || cellType == "inlineStr") {
                            while (row.size <= currentColumn) row.add("")
                            row[currentColumn] = raw
                        } else {
                            val value = if (cellType == "s") sharedStrings.getOrNull(raw.toIntOrNull() ?: -1) ?: "" else raw
                            while (row.size <= currentColumn) row.add("")
                            row[currentColumn] = value
                        }
                    }
                }
                XmlPullParser.END_TAG -> if (parser.name == "row" && row.any { it.isNotBlank() }) rows.add(row.toList())
            }
            event = parser.next()
        }
        return rows
    }

    fun getXlsxRows(context: Context, uri: Uri): List<List<String>> {
        return try {
            val shared = readZipEntry(context, uri, "xl/sharedStrings.xml")?.let { parseSharedStrings(it) } ?: emptyList()
            val sheet = readZipEntry(context, uri, "xl/worksheets/sheet1.xml") ?: return emptyList()
            parseWorksheet(sheet, shared)
        } catch (_: Exception) { emptyList() }
    }

    fun getSpreadsheetHeaders(context: Context, uri: Uri): List<String> {
        val name = uri.toString().lowercase(Locale.US)
        return if (name.endsWith(".xlsx") || name.contains("xlsx")) {
            getXlsxRows(context, uri).firstOrNull() ?: emptyList()
        } else getCsvHeaders(context, uri)
    }

    fun importProductsFromXlsxMapped(
        context: Context,
        uri: Uri,
        nameIdx: Int,
        barcodeIdx: Int,
        purchaseIdx: Int,
        sellIdx: Int,
        qtyIdx: Int,
        catIdx: Int,
        expiryIdx: Int,
        onSuccess: (Int) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val rows = getXlsxRows(context, uri)
        if (rows.size <= 1) {
            onFailure("ملف XLSX فارغ أو لا يحتوي على ورقة العمل الأولى")
            return
        }
        importProductsFromSpreadsheetRows(rows.drop(1), nameIdx, barcodeIdx, purchaseIdx, sellIdx, qtyIdx, catIdx, expiryIdx, onSuccess, onFailure)
    }

    private fun importProductsFromSpreadsheetRows(
        rows: List<List<String>>,
        nameIdx: Int,
        barcodeIdx: Int,
        purchaseIdx: Int,
        sellIdx: Int,
        qtyIdx: Int,
        catIdx: Int,
        expiryIdx: Int,
        onSuccess: (Int) -> Unit,
        onFailure: (String) -> Unit
    ) {
        try {
            val productsToSave = mutableListOf<Product>()
            var count = 0
            rows.forEachIndexed { rowIndex, columns ->
                if (columns.all { it.isBlank() }) return@forEachIndexed
                fun column(index: Int, fallback: String = ""): String = if (index in columns.indices) columns[index].trim() else fallback
                val name = column(nameIdx)
                if (name.isBlank()) return@forEachIndexed
                val purchase = column(purchaseIdx, "0").replace(",", ".").toDoubleOrNull()
                val selling = column(sellIdx, "0").replace(",", ".").toDoubleOrNull()
                val quantity = column(qtyIdx, "0").replace(",", ".").toDoubleOrNull()
                val expiry = parseSpreadsheetDate(column(expiryIdx))
                if (purchase == null || selling == null || quantity == null || purchase < 0 || selling <= 0 || quantity < 0 || expiry == null) {
                    onFailure("بيانات غير صالحة في صف Excel رقم ${rowIndex + 2}")
                    return
                }
                val purchaseValue = purchase
                val sellingValue = selling
                val quantityValue = quantity
                val expiryValue = expiry
                val barcode = column(barcodeIdx)
                val category = column(catIdx, "عام").ifBlank { "عام" }
                val existingIndex = productList.indexOfFirst { (barcode.isNotBlank() && it.barcode == barcode) || it.name.trim().equals(name, true) }
                val product = if (existingIndex >= 0) {
                    productList[existingIndex].copy(
                        purchasePrice = purchaseValue, sellingPrice = sellingValue,
                        stockQuantity = productList[existingIndex].stockQuantity + quantityValue,
                        barcode = barcode.ifBlank { productList[existingIndex].barcode },
                        category = category, expiryDate = if (expiryValue > 0) expiryValue else productList[existingIndex].expiryDate
                    )
                } else Product(
                    id = UUID.randomUUID().toString(), name = name, barcode = barcode,
                    purchasePrice = purchaseValue, sellingPrice = sellingValue, stockQuantity = quantityValue,
                    category = category, expiryDate = expiryValue
                )
                val error = product.validationError()
                if (error != null) {
                    onFailure("صف Excel رقم ${rowIndex + 2}: $error")
                    return
                }
                if (existingIndex >= 0) productList[existingIndex] = product else productList.add(product)
                productsToSave.add(product)
                count++
            }
            if (productsToSave.isEmpty()) onFailure("لم يتم العثور على منتجات صالحة في ملف Excel")
            else {
                dbHelper.insertBatchProducts(productsToSave)
                autoSyncToCloud()
                onSuccess(count)
            }
        } catch (e: Exception) { onFailure("تعذر قراءة ملف XLSX: ${e.message ?: "صيغة غير مدعومة"}") }
    }
}
