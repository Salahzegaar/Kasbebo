package com.example.bookstoremanager.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.Transaction
import java.security.MessageDigest
import java.util.UUID

/**
 * Authentication/session boundary.
 *
 * Security rules, not the client, are the authority for store ownership and roles.
 * The store code is only a locator; it is never treated as a credential.
 */
class AuthManager(private val context: Context) {

    private val dbRef = FirebaseDatabase.getInstance().reference
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    fun generateUniqueStoreCode(): String {
        // 48 bits of random UUID material is sufficient for a non-credential locator.
        return "KSB-" + UUID.randomUUID().toString().replace("-", "").take(12).uppercase()
    }

    fun registerNewStore(
        email: String,
        pass: String,
        onSuccess: (storeCode: String) -> Unit,
        onFailure: (errorMessage: String) -> Unit
    ) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || pass.length < 6) {
            onFailure("البريد الإلكتروني أو كلمة المرور غير صالحة.")
            return
        }

        val generatedStoreCode = generateUniqueStoreCode()

        auth.createUserWithEmailAndPassword(cleanEmail, pass)
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    onFailure(task.exception?.message ?: "فشل إنشاء الحساب.")
                    return@addOnCompleteListener
                }

                val uid = auth.currentUser?.uid
                if (uid.isNullOrBlank()) {
                    auth.signOut()
                    onFailure("تعذر تحديد هوية الحساب الجديد.")
                    return@addOnCompleteListener
                }

                val userData = hashMapOf<String, Any>(
                    "email" to cleanEmail,
                    "storeCode" to generatedStoreCode,
                    "uid" to uid,
                    "createdTimestamp" to System.currentTimeMillis()
                )

                val storeData = hashMapOf<String, Any>(
                    "storeUserEmail" to cleanEmail,
                    "storeCode" to generatedStoreCode,
                    "ownerUid" to uid,
                    "createdTimestamp" to System.currentTimeMillis()
                )

                // Atomic multi-location write: no orphan user/store pair.
                val updates = hashMapOf<String, Any>(
                    "Kasebo_Users/$uid" to userData,
                    "Kasebo_Stores/$generatedStoreCode" to storeData
                )

                dbRef.updateChildren(updates)
                    .addOnSuccessListener {
                        SessionStore.save(context, generatedStoreCode, uid, "Admin")
                        onSuccess(generatedStoreCode)
                    }
                    .addOnFailureListener { e ->
                        // The Firebase Auth account remains valid, but we do not create
                        // a local session when the store record was not created.
                        auth.signOut()
                        onFailure(e.message ?: "تعذر إنشاء بيانات المتجر.")
                    }
            }
    }

    fun loginStore(
        email: String,
        pass: String,
        onSuccess: (storeCode: String) -> Unit,
        onFailure: (errorMessage: String) -> Unit
    ) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || pass.isBlank()) {
            onFailure("يرجى إدخال البريد الإلكتروني وكلمة السر.")
            return
        }

        auth.signInWithEmailAndPassword(cleanEmail, pass)
            .addOnCompleteListener { authTask ->
                if (!authTask.isSuccessful) {
                    onFailure("البريد الإلكتروني أو كلمة المرور غير صحيحة.")
                    return@addOnCompleteListener
                }
                val uid = auth.currentUser?.uid
                if (uid.isNullOrBlank()) {
                    auth.signOut()
                    onFailure("تعذر تحديد هوية الحساب.")
                    return@addOnCompleteListener
                }
                loadUserRoleAndStore(uid, cleanEmail, onSuccess, onFailure)
            }
    }

    private fun loadUserRoleAndStore(
        uid: String,
        email: String,
        onSuccess: (String) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val userRef = dbRef.child("Kasebo_Users").child(uid)
        userRef.get().addOnSuccessListener { snapshot ->
            if (snapshot.exists()) {
                val storeCode = snapshot.child("storeCode").getValue(String::class.java).orEmpty()
                if (storeCode.isBlank()) {
                    auth.signOut(); onFailure("بيانات حساب المتجر غير مكتملة."); return@addOnSuccessListener
                }
                finishRoleAwareLogin(uid, email, storeCode, onSuccess, onFailure)
                return@addOnSuccessListener
            }

            val legacyKey = email.lowercase().replace(".", "_").replace("@", "_")
            dbRef.child("Kasebo_Users").child(legacyKey).get()
                .addOnSuccessListener { legacy ->
                    val legacyUid = legacy.child("uid").getValue(String::class.java)
                    val legacyStore = legacy.child("storeCode").getValue(String::class.java).orEmpty()
                    if (!legacy.exists() || legacyUid != uid || legacyStore.isBlank()) {
                        auth.signOut(); onFailure("بيانات حساب المتجر غير مكتملة."); return@addOnSuccessListener
                    }
                    val migrated = hashMapOf<String, Any>(
                        "email" to email, "storeCode" to legacyStore, "uid" to uid,
                        "createdTimestamp" to (legacy.child("createdTimestamp").value ?: System.currentTimeMillis()),
                        "role" to "owner"
                    )
                    userRef.setValue(migrated).addOnSuccessListener {
                        finishRoleAwareLogin(uid, email, legacyStore, onSuccess, onFailure)
                    }.addOnFailureListener { auth.signOut(); onFailure("تعذر ترحيل بيانات الحساب.") }
                }
                .addOnFailureListener { auth.signOut(); onFailure("فشل الاتصال ببيانات الحساب.") }
        }.addOnFailureListener { auth.signOut(); onFailure("فشل الاتصال ببيانات الحساب.") }
    }

    private fun finishRoleAwareLogin(
        uid: String,
        email: String,
        storeCode: String,
        onSuccess: (String) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val storeRef = dbRef.child("Kasebo_Stores").child(storeCode)
        storeRef.get().addOnSuccessListener { store ->
            if (!store.exists()) { auth.signOut(); onFailure("المتجر غير موجود."); return@addOnSuccessListener }
            val ownerUid = store.child("ownerUid").getValue(String::class.java).orEmpty()
            if (ownerUid == uid) {
                SessionStore.save(context, storeCode, uid, "Admin")
                onSuccess(storeCode)
                return@addOnSuccessListener
            }
            val member = store.child("members").child(uid)
            if (!member.exists()) {
                auth.signOut(); onFailure("هذا الحساب غير مرتبط بمتجر أو تم تعطيل عضويته."); return@addOnSuccessListener
            }
            val active = member.child("active").getValue(Boolean::class.java) ?: true
            if (!active) {
                auth.signOut(); onFailure("تم تعطيل حساب الموظف من هذا المتجر."); return@addOnSuccessListener
            }
            val role = member.child("role").getValue(String::class.java).orEmpty().lowercase()
            val sessionRole = when (role) { "admin" -> "Admin"; "cashier" -> "Cashier"; else -> "" }
            if (sessionRole.isBlank()) {
                auth.signOut(); onFailure("دور المستخدم غير صالح."); return@addOnSuccessListener
            }
            val memberEmail = member.child("email").getValue(String::class.java).orEmpty()
            if (memberEmail.isNotBlank() && !memberEmail.equals(email, ignoreCase = true)) {
                auth.signOut(); onFailure("بيانات هوية الموظف غير متطابقة."); return@addOnSuccessListener
            }
            SessionStore.save(context, storeCode, uid, sessionRole)
            onSuccess(storeCode)
        }.addOnFailureListener { auth.signOut(); onFailure("تعذر التحقق من صلاحيات المتجر.") }
    }

    fun createEmployeeInvite(
        storeCode: String,
        email: String,
        role: String,
        displayName: String,
        onSuccess: (String) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val uid = auth.currentUser?.uid
        val cleanEmail = email.trim().lowercase()
        val normalizedRole = role.lowercase()
        if (uid.isNullOrBlank() || storeCode.isBlank()) { onFailure("الجلسة غير صالحة."); return }
        if (cleanEmail.isBlank() || !cleanEmail.contains("@")) { onFailure("البريد الإلكتروني غير صالح."); return }
        if (normalizedRole != "admin" && normalizedRole != "cashier") { onFailure("الدور يجب أن يكون مديرًا أو كاشيرًا."); return }
        val token = (UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "")).take(24).uppercase()
        val now = System.currentTimeMillis()
        val emailKey = emailIndexKey(cleanEmail)
        val storeRef = dbRef.child("Kasebo_Stores").child(storeCode)
        val indexRef = storeRef.child("employeeInviteIndex").child(emailKey)
        val inviteRef = storeRef.child("employeeInvites").child(token)
        val invite = hashMapOf<String, Any>(
            "storeId" to storeCode, "email" to cleanEmail, "emailKey" to emailKey, "role" to normalizedRole,
            "displayName" to displayName.trim(), "createdBy" to uid, "createdAt" to now,
            "expiresAt" to (now + 7L * 24L * 60L * 60L * 1000L), "status" to "pending"
        )

        // Reserve the normalized email atomically first. This guarantees that one email
        // can have only one invitation in this store, even if two devices create invites
        // at the same time. The reservation is released if the invite write fails.
        indexRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: com.google.firebase.database.MutableData): Transaction.Result {
                if (currentData.value != null) return Transaction.abort()
                currentData.value = hashMapOf<String, Any>(
                    "token" to token, "email" to cleanEmail, "status" to "pending",
                    "createdBy" to uid, "createdAt" to now
                )
                return Transaction.success(currentData)
            }

            override fun onComplete(error: com.google.firebase.database.DatabaseError?, committed: Boolean, snapshot: com.google.firebase.database.DataSnapshot?) {
                if (error != null) {
                    onFailure("تعذر إنشاء الدعوة: ${error.message}")
                    return
                }
                if (!committed) {
                    onFailure("يوجد بالفعل رمز دعوة لهذا البريد الإلكتروني. استخدم الرمز المحفوظ أو انتظر انتهاء/إتمام الدعوة الحالية.")
                    return
                }
                inviteRef.setValue(invite)
                    .addOnSuccessListener { onSuccess(token) }
                    .addOnFailureListener {
                        indexRef.get().addOnSuccessListener { current ->
                            if (current.child("token").getValue(String::class.java) == token) indexRef.removeValue()
                        }
                        onFailure(it.message ?: "تعذر إنشاء دعوة الموظف.")
                    }
            }
        })
    }

    private fun emailIndexKey(email: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(email.trim().lowercase().toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    data class EmployeeInvite(
        val token: String,
        val storeId: String,
        val email: String,
        val role: String,
        val displayName: String,
        val createdAt: Long,
        val expiresAt: Long,
        val status: String
    )

    fun getEmployeeInvites(
        storeCode: String,
        onSuccess: (List<EmployeeInvite>) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank() || storeCode.isBlank()) {
            onFailure("الجلسة غير صالحة.")
            return
        }
        val invitesRef = dbRef.child("Kasebo_Stores").child(storeCode).child("employeeInvites")
        val invitesTask = if (SessionStore.hasRole(context, "Admin")) {
            invitesRef.get()
        } else {
            invitesRef.orderByChild("createdBy").equalTo(uid).get()
        }
        invitesTask.addOnSuccessListener { snapshot ->
                val invites = snapshot.children.mapNotNull { child ->
                    val token = child.key.orEmpty()
                    if (token.isBlank()) return@mapNotNull null
                    EmployeeInvite(
                        token = token,
                        storeId = child.child("storeId").getValue(String::class.java).orEmpty(),
                        email = child.child("email").getValue(String::class.java).orEmpty(),
                        role = child.child("role").getValue(String::class.java).orEmpty(),
                        displayName = child.child("displayName").getValue(String::class.java).orEmpty(),
                        createdAt = child.child("createdAt").getValue(Long::class.java) ?: 0L,
                        expiresAt = child.child("expiresAt").getValue(Long::class.java) ?: 0L,
                        status = child.child("status").getValue(String::class.java).orEmpty()
                    )
                }.sortedByDescending { it.createdAt }
                onSuccess(invites)
            }
            .addOnFailureListener { onFailure(it.message ?: "تعذر تحميل دعوات الموظفين.") }
    }

    fun deleteEmployeeAndInvite(
        storeCode: String,
        inviteToken: String,
        email: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank() || storeCode.isBlank()) {
            onFailure("الجلسة غير صالحة.")
            return
        }
        if (!SessionStore.hasRole(context, "Admin") && !SessionStore.hasRole(context, "Owner")) {
            onFailure("لا تملك صلاحية حذف الموظف.")
            return
        }
        val storeRef = dbRef.child("Kasebo_Stores").child(storeCode)
        fun removeForInvite(token: String, invite: com.google.firebase.database.DataSnapshot?) {
            if (token.isBlank()) { onSuccess(); return }
            val claimedUid = invite?.child("claimedUid")?.getValue(String::class.java).orEmpty()
            val inviteEmail = invite?.child("email")?.getValue(String::class.java).orEmpty().ifBlank { email.trim().lowercase() }
            val emailKey = emailIndexKey(inviteEmail)
            val updates = hashMapOf<String, Any?>(
                "employeeInvites/$token" to null,
                "employeeInviteIndex/$emailKey" to null
            )
            if (claimedUid.isNotBlank()) {
                updates["members/$claimedUid"] = null
            }
            storeRef.updateChildren(updates)
                .addOnSuccessListener { onSuccess() }
                .addOnFailureListener { onFailure("تعذر حذف الموظف والدعوة: ${it.message ?: "خطأ"}") }
        }

        if (inviteToken.isNotBlank()) {
            storeRef.child("employeeInvites").child(inviteToken.uppercase()).get()
                .addOnSuccessListener { snapshot -> removeForInvite(inviteToken.uppercase(), snapshot) }
                .addOnFailureListener { onFailure("تعذر العثور على دعوة الموظف.") }
        } else if (email.trim().isNotBlank()) {
            val cleanEmail = email.trim().lowercase()
            storeRef.child("employeeInvites").orderByChild("email").equalTo(cleanEmail).get()
                .addOnSuccessListener { snapshot ->
                    val invite = snapshot.children.firstOrNull()
                    if (invite == null) onSuccess()
                    else removeForInvite(invite.key.orEmpty(), invite)
                }
                .addOnFailureListener { onFailure("تعذر البحث عن دعوة الموظف.") }
        } else {
            onSuccess()
        }
    }

    fun registerEmployeeWithInvite(
        email: String,
        pass: String,
        inviteToken: String,
        onSuccess: (String) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val cleanEmail = email.trim().lowercase()
        val token = inviteToken.trim().uppercase()
        if (cleanEmail.isBlank() || pass.length < 6 || token.length < 12) { onFailure("البريد أو كلمة السر أو رمز الدعوة غير صالح."); return }
        dbRef.child("Kasebo_Stores").get().addOnSuccessListener { stores ->
            var foundStore = ""
            var inviteSnapshot: com.google.firebase.database.DataSnapshot? = null
            for (store in stores.children) {
                val candidate = store.child("employeeInvites").child(token)
                if (candidate.exists()) { foundStore = store.key.orEmpty(); inviteSnapshot = candidate; break }
            }
            if (foundStore.isBlank() || inviteSnapshot == null) { onFailure("رمز الدعوة غير موجود."); return@addOnSuccessListener }
            val invite = inviteSnapshot
            val expiresAt = invite.child("expiresAt").getValue(Long::class.java) ?: 0L
            if (invite.child("status").getValue(String::class.java) != "pending" || expiresAt < System.currentTimeMillis()) { onFailure("الدعوة منتهية أو مستخدمة."); return@addOnSuccessListener }
            if (!invite.child("email").getValue(String::class.java).orEmpty().equals(cleanEmail, ignoreCase = true)) { onFailure("البريد الإلكتروني لا يطابق الدعوة."); return@addOnSuccessListener }

            auth.createUserWithEmailAndPassword(cleanEmail, pass).addOnCompleteListener { task ->
                if (!task.isSuccessful) { onFailure(task.exception?.message ?: "فشل إنشاء حساب الموظف."); return@addOnCompleteListener }
                val newUid = auth.currentUser?.uid
                if (newUid.isNullOrBlank()) { auth.signOut(); onFailure("تعذر تحديد هوية الموظف."); return@addOnCompleteListener }
                val role = invite.child("role").getValue(String::class.java).orEmpty().lowercase()
                val userData = hashMapOf<String, Any>("email" to cleanEmail, "storeCode" to foundStore, "uid" to newUid, "role" to role, "createdTimestamp" to System.currentTimeMillis())
                val memberData = hashMapOf<String, Any>("uid" to newUid, "email" to cleanEmail, "role" to role, "displayName" to invite.child("displayName").getValue(String::class.java).orEmpty(), "inviteToken" to token, "joinedAt" to System.currentTimeMillis(), "active" to true)
                val updates = hashMapOf<String, Any>(
                    "Kasebo_Users/$newUid" to userData,
                    "Kasebo_Stores/$foundStore/members/$newUid" to memberData,
                    "Kasebo_Stores/$foundStore/employeeInvites/$token/status" to "claimed",
                    "Kasebo_Stores/$foundStore/employeeInvites/$token/claimedUid" to newUid,
                    "Kasebo_Stores/$foundStore/employeeInvites/$token/claimedAt" to System.currentTimeMillis(),
                    "Kasebo_Stores/$foundStore/employeeInviteIndex/${emailIndexKey(cleanEmail)}/status" to "claimed",
                    "Kasebo_Stores/$foundStore/employeeInviteIndex/${emailIndexKey(cleanEmail)}/claimedUid" to newUid,
                    "Kasebo_Stores/$foundStore/employeeInviteIndex/${emailIndexKey(cleanEmail)}/claimedAt" to System.currentTimeMillis()
                )
                dbRef.updateChildren(updates).addOnSuccessListener {
                    val sessionRole = if (role == "admin") "Admin" else "Cashier"
                    SessionStore.save(context, foundStore, newUid, sessionRole)
                    onSuccess(foundStore)
                }.addOnFailureListener { auth.signOut(); onFailure("تعذر إكمال ربط الموظف بالمتجر: ${it.message ?: "خطأ"}") }
            }
        }.addOnFailureListener { onFailure("تعذر قراءة دعوة الموظف.") }
    }

    fun validateSession(storeCode: String, onValid: () -> Unit, onInvalid: () -> Unit) {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank() || storeCode.isBlank()) {
            onInvalid()
            return
        }

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val online = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val network = cm?.activeNetwork
            val caps = network?.let { cm.getNetworkCapabilities(it) }
            caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } else {
            @Suppress("DEPRECATION")
            cm?.activeNetworkInfo?.isConnected == true
        }

        if (!online) {
            // Offline relaunch: Firebase Auth still identifies the same signed-in UID,
            // while the store-local cache is namespaced by store. Do not erase the
            // session merely because the server cannot be reached. A server validation
            // is still performed automatically as soon as connectivity returns.
            if (SessionStore.uid(context) == uid && SessionStore.storeId(context) == storeCode.trim()) {
                onValid()
            } else {
                onInvalid()
            }
            return
        }

        dbRef.child("Kasebo_Stores").child(storeCode).child("ownerUid").get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.getValue(String::class.java) == uid) onValid() else onInvalid()
            }
            .addOnFailureListener { onInvalid() }
    }

    fun logout() {
        auth.signOut()
        SessionStore.clear(context)
    }
}
