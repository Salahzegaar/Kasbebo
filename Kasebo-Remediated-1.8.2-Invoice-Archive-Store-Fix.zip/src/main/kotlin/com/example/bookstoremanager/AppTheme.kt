package com.example.bookstoremanager

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object AppTheme {
    // 🌟 الألوان الأساسية الفاخرة (التصميم الجديد)
    val PremiumGold: Color = Color(0xFF6366F1)
    val PremiumGoldDark: Color = Color(0xFF4338CA)
    val PremiumGoldLight: Color = Color(0xFF38BDF8)

    // تدرج ذهبي للأزرار الفاخرة
    val GoldGradient = Brush.horizontalGradient(
        colors = listOf(PremiumGoldLight, PremiumGoldDark)
    )

    // 🌟 جسر التوافق (هذا الجزء سيحل جميع الأخطاء دفعة واحدة)
    val GoldPrimary: Color = PremiumGold
    val GoldPrimaryText: Color = PremiumGoldDark
    val ColorDanger: Color = Color(0xFFEF476F)
    val ColorSuccess: Color = Color(0xFF14B8A6)
    val AccentTeal: Color = Color(0xFF14B8A6)
    val AccentSky: Color = Color(0xFF38BDF8)

    // 🎨 دوال الوضع الليلي والنهاري (Theme Engine)
    fun bg(isDark: Boolean): Color = if (isDark) Color(0xFF0B1020) else Color(0xFFF5F7FF)
    fun card(isDark: Boolean): Color = if (isDark) Color(0xFF121A2E) else Color(0xFFFFFFFF)
    fun inputBg(isDark: Boolean): Color = if (isDark) Color(0xFF1B2742) else Color(0xFFEEF2FF)

    fun text(isDark: Boolean): Color = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    fun subText(isDark: Boolean): Color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)

    fun cardBorder(isDark: Boolean): Color = if (isDark) Color(0xFF94A3B8).copy(alpha = 0.16f) else Color(0xFFDDE3F0)
}
